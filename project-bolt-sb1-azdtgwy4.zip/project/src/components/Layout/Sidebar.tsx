import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Clock, 
  Calendar, 
  DollarSign, 
  Target, 
  Briefcase, 
  GraduationCap, 
  BarChart3, 
  Settings,
  ChevronLeft,
  ChevronRight,
  Shield,
  UserCog
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';

interface SidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isCollapsed, onToggle }) => {
  const { user, hasPermission } = useAuth();
  const { t } = useLanguage();

  const navigationItems = [
    {
      name: t('nav.dashboard'),
      href: '/dashboard',
      icon: LayoutDashboard,
      permission: 'dashboard.view'
    },
    {
      name: t('nav.employees'),
      href: '/employees',
      icon: Users,
      permission: 'employees.view'
    },
    {
      name: t('nav.attendance'),
      href: '/attendance',
      icon: Clock,
      permission: 'attendance.view'
    },
    {
      name: t('nav.leaves'),
      href: '/leaves',
      icon: Calendar,
      permission: 'leaves.view'
    },
    {
      name: t('nav.payroll'),
      href: '/payroll',
      icon: DollarSign,
      permission: 'payroll.view'
    },
    {
      name: t('nav.performance'),
      href: '/performance',
      icon: Target,
      permission: 'performance.view'
    },
    {
      name: t('nav.recruitment'),
      href: '/recruitment',
      icon: Briefcase,
      permission: 'recruitment.view'
    },
    {
      name: t('nav.training'),
      href: '/training',
      icon: GraduationCap,
      permission: 'training.view'
    },
    {
      name: t('nav.reports'),
      href: '/reports',
      icon: BarChart3,
      permission: 'reports.view'
    },
    {
      name: 'User Management',
      href: '/user-management',
      icon: UserCog,
      permission: 'users.manage'
    },
    {
      name: t('nav.settings'),
      href: '/settings',
      icon: Settings,
      permission: 'settings.view'
    }
  ];

  const visibleItems = navigationItems.filter(item => hasPermission(item.permission));

  return (
    <div className={`bg-slate-900 text-white transition-all duration-300 ${
      isCollapsed ? 'w-16' : 'w-64'
    } h-screen flex flex-col`}>
      {/* Header */}
      <div className="p-4 border-b border-slate-700">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div>
              <h1 className="text-xl font-bold text-blue-400">HRM Pro</h1>
              <p className="text-xs text-slate-400">Human Resources</p>
            </div>
          )}
          <button
            onClick={onToggle}
            className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
          >
            {isCollapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
          </button>
        </div>
      </div>

      {/* User Info */}
      {!isCollapsed && user && (
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium">
                {user.firstName[0]}{user.lastName[0]}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">
                {user.firstName} {user.lastName}
              </p>
              <p className="text-xs text-slate-400 truncate">{user.position}</p>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {visibleItems.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.href}>
                <NavLink
                  to={item.href}
                  className={({ isActive }) =>
                    `flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                      isActive
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`
                  }
                >
                  <Icon size={20} />
                  {!isCollapsed && <span className="truncate">{item.name}</span>}
                </NavLink>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-slate-700">
        <div className="text-xs text-slate-500 text-center">
          {!isCollapsed && 'HRM Pro v1.0'}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;