import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  hasPermission: (permission: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const mockUsers: User[] = [
  {
    id: '1',
    email: 'admin@company.com',
    firstName: 'System',
    lastName: 'Administrator',
    role: 'admin',
    department: 'IT',
    position: 'System Administrator',
    timezone: 'UTC',
    language: 'en',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    lastLogin: '2024-01-15T09:00:00Z'
  },
  {
    id: '2',
    email: 'hr@company.com',
    firstName: 'Sarah',
    lastName: 'Johnson',
    role: 'hr_manager',
    department: 'Human Resources',
    position: 'HR Manager',
    timezone: 'America/New_York',
    language: 'en',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    lastLogin: '2024-01-15T08:30:00Z'
  },
  {
    id: '3',
    email: 'employee@company.com',
    firstName: 'John',
    lastName: 'Doe',
    role: 'employee',
    department: 'Engineering',
    position: 'Software Developer',
    timezone: 'Europe/London',
    language: 'en',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    lastLogin: '2024-01-15T07:45:00Z'
  },
  {
    id: '4',
    email: 'manager@company.com',
    firstName: 'Emily',
    lastName: 'Chen',
    role: 'department_head',
    department: 'Engineering',
    position: 'Engineering Manager',
    timezone: 'Asia/Singapore',
    language: 'en',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    lastLogin: '2024-01-15T08:00:00Z'
  }
];

const rolePermissions = {
  admin: ['*'],
  hr_manager: ['employees.*', 'attendance.*', 'leaves.*', 'payroll.*', 'recruitment.*', 'training.*'],
  department_head: ['employees.view', 'attendance.view', 'leaves.approve', 'performance.*'],
  employee: ['profile.view', 'profile.edit', 'attendance.view', 'leaves.create', 'performance.view']
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('authToken');
    const userData = localStorage.getItem('userData');
    
    if (token && userData) {
      try {
        const parsedUser = JSON.parse(userData);
        setUser(parsedUser);
      } catch (error) {
        localStorage.removeItem('authToken');
        localStorage.removeItem('userData');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const foundUser = mockUsers.find(u => u.email === email);
    
    if (foundUser && password === 'password') {
      const token = `mock-jwt-token-${foundUser.id}`;
      localStorage.setItem('authToken', token);
      localStorage.setItem('userData', JSON.stringify(foundUser));
      setUser(foundUser);
      setIsLoading(false);
      return true;
    }
    
    setIsLoading(false);
    return false;
  };

  const logout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userData');
    setUser(null);
  };

  const hasPermission = (permission: string): boolean => {
    if (!user) return false;
    
    const permissions = rolePermissions[user.role] || [];
    
    return permissions.includes('*') || 
           permissions.includes(permission) ||
           permissions.some(p => p.endsWith('.*') && permission.startsWith(p.slice(0, -1)));
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading, hasPermission }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};