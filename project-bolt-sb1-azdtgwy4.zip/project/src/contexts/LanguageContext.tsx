import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'en' | 'fr' | 'ar' | 'bn';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.employees': 'Employees',
    'nav.attendance': 'Attendance',
    'nav.leaves': 'Leave Management',
    'nav.payroll': 'Payroll',
    'nav.performance': 'Performance',
    'nav.recruitment': 'Recruitment',
    'nav.training': 'Training',
    'nav.reports': 'Reports',
    'nav.settings': 'Settings',
    
    // Common
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.edit': 'Edit',
    'common.delete': 'Delete',
    'common.view': 'View',
    'common.search': 'Search',
    'common.filter': 'Filter',
    'common.export': 'Export',
    'common.loading': 'Loading...',
    'common.noData': 'No data available',
    
    // Auth
    'auth.login': 'Login',
    'auth.logout': 'Logout',
    'auth.email': 'Email',
    'auth.password': 'Password',
    'auth.signIn': 'Sign In',
    'auth.welcomeBack': 'Welcome back',
    'auth.signInToContinue': 'Sign in to your account to continue',
    
    // Dashboard
    'dashboard.welcome': 'Welcome back',
    'dashboard.totalEmployees': 'Total Employees',
    'dashboard.activeEmployees': 'Active Employees',
    'dashboard.pendingLeaves': 'Pending Leaves',
    'dashboard.todayAttendance': 'Today\'s Attendance',
    'dashboard.upcomingBirthdays': 'Upcoming Birthdays',
    'dashboard.recentHires': 'Recent Hires',
    
    // Employees
    'employees.title': 'Employee Management',
    'employees.addNew': 'Add New Employee',
    'employees.directory': 'Employee Directory',
    'employees.profile': 'Employee Profile',
    'employees.documents': 'Documents',
    'employees.skills': 'Skills',
    'employees.performance': 'Performance',
    
    // Attendance
    'attendance.title': 'Attendance Management',
    'attendance.clockIn': 'Clock In',
    'attendance.clockOut': 'Clock Out',
    'attendance.today': 'Today',
    'attendance.thisWeek': 'This Week',
    'attendance.thisMonth': 'This Month',
    
    // Leaves
    'leaves.title': 'Leave Management',
    'leaves.apply': 'Apply for Leave',
    'leaves.pending': 'Pending',
    'leaves.approved': 'Approved',
    'leaves.rejected': 'Rejected',
    'leaves.balance': 'Leave Balance',
    
    // Performance
    'performance.title': 'Performance Management',
    'performance.goals': 'Goals',
    'performance.reviews': 'Reviews',
    'performance.feedback': 'Feedback',
    
    // Recruitment
    'recruitment.title': 'Recruitment',
    'recruitment.jobs': 'Job Openings',
    'recruitment.applications': 'Applications',
    'recruitment.interviews': 'Interviews',
    
    // Training
    'training.title': 'Training & Development',
    'training.courses': 'Training Courses',
    'training.certifications': 'Certifications',
    'training.skills': 'Skills Development'
  },
  fr: {
    // Navigation
    'nav.dashboard': 'Tableau de bord',
    'nav.employees': 'Employés',
    'nav.attendance': 'Présence',
    'nav.leaves': 'Gestion des congés',
    'nav.payroll': 'Paie',
    'nav.performance': 'Performance',
    'nav.recruitment': 'Recrutement',
    'nav.training': 'Formation',
    'nav.reports': 'Rapports',
    'nav.settings': 'Paramètres',
    
    // Common
    'common.save': 'Enregistrer',
    'common.cancel': 'Annuler',
    'common.edit': 'Modifier',
    'common.delete': 'Supprimer',
    'common.view': 'Voir',
    'common.search': 'Rechercher',
    'common.filter': 'Filtrer',
    'common.export': 'Exporter',
    'common.loading': 'Chargement...',
    'common.noData': 'Aucune donnée disponible',
    
    // Auth
    'auth.login': 'Connexion',
    'auth.logout': 'Déconnexion',
    'auth.email': 'Email',
    'auth.password': 'Mot de passe',
    'auth.signIn': 'Se connecter',
    'auth.welcomeBack': 'Bon retour',
    'auth.signInToContinue': 'Connectez-vous à votre compte pour continuer',
    
    // Dashboard
    'dashboard.welcome': 'Bon retour',
    'dashboard.totalEmployees': 'Total Employés',
    'dashboard.activeEmployees': 'Employés Actifs',
    'dashboard.pendingLeaves': 'Congés en Attente',
    'dashboard.todayAttendance': 'Présence Aujourd\'hui',
    'dashboard.upcomingBirthdays': 'Anniversaires à Venir',
    'dashboard.recentHires': 'Embauches Récentes'
  },
  ar: {
    // Navigation
    'nav.dashboard': 'لوحة القيادة',
    'nav.employees': 'الموظفون',
    'nav.attendance': 'الحضور',
    'nav.leaves': 'إدارة الإجازات',
    'nav.payroll': 'كشف المرتبات',
    'nav.performance': 'الأداء',
    'nav.recruitment': 'التوظيف',
    'nav.training': 'التدريب',
    'nav.reports': 'التقارير',
    'nav.settings': 'الإعدادات',
    
    // Common
    'common.save': 'حفظ',
    'common.cancel': 'إلغاء',
    'common.edit': 'تعديل',
    'common.delete': 'حذف',
    'common.view': 'عرض',
    'common.search': 'بحث',
    'common.filter': 'تصفية',
    'common.export': 'تصدير',
    'common.loading': 'جاري التحميل...',
    'common.noData': 'لا توجد بيانات متاحة',
    
    // Auth
    'auth.login': 'تسجيل الدخول',
    'auth.logout': 'تسجيل الخروج',
    'auth.email': 'البريد الإلكتروني',
    'auth.password': 'كلمة المرور',
    'auth.signIn': 'تسجيل الدخول',
    'auth.welcomeBack': 'مرحباً بعودتك',
    'auth.signInToContinue': 'سجل دخولك إلى حسابك للمتابعة'
  },
  bn: {
    // Navigation
    'nav.dashboard': 'ড্যাশবোর্ড',
    'nav.employees': 'কর্মচারীরা',
    'nav.attendance': 'উপস্থিতি',
    'nav.leaves': 'ছুটি ব্যবস্থাপনা',
    'nav.payroll': 'বেতন',
    'nav.performance': 'কর্মক্ষমতা',
    'nav.recruitment': 'নিয়োগ',
    'nav.training': 'প্রশিক্ষণ',
    'nav.reports': 'রিপোর্ট',
    'nav.settings': 'সেটিংস',
    
    // Common
    'common.save': 'সংরক্ষণ',
    'common.cancel': 'বাতিল',
    'common.edit': 'সম্পাদনা',
    'common.delete': 'মুছুন',
    'common.view': 'দেখুন',
    'common.search': 'অনুসন্ধান',
    'common.filter': 'ফিল্টার',
    'common.export': 'রপ্তানি',
    'common.loading': 'লোড হচ্ছে...',
    'common.noData': 'কোনো ডেটা উপলব্ধ নেই',
    
    // Auth
    'auth.login': 'লগইন',
    'auth.logout': 'লগআউট',
    'auth.email': 'ইমেইল',
    'auth.password': 'পাসওয়ার্ড',
    'auth.signIn': 'সাইন ইন',
    'auth.welcomeBack': 'স্বাগতম',
    'auth.signInToContinue': 'চালিয়ে যেতে আপনার অ্যাকাউন্টে সাইন ইন করুন'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    if (savedLanguage && translations[savedLanguage]) {
      setLanguage(savedLanguage);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('language', lang);
    
    // Update document direction for RTL languages
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  };

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};