import React, { useState } from 'react';
import { Calendar, Clock, CheckCircle, XCircle, AlertCircle, Plus, Filter, Download } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { format, parseISO, differenceInDays } from 'date-fns';

const LeaveManagement: React.FC = () => {
  const { t } = useLanguage();
  const { user, hasPermission } = useAuth();
  const [activeTab, setActiveTab] = useState<'requests' | 'balance' | 'calendar' | 'apply'>('requests');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [showApplyModal, setShowApplyModal] = useState(false);

  const mockLeaveRequests = [
    {
      id: '1',
      employeeId: 'EMP001',
      employeeName: 'John Doe',
      department: 'Engineering',
      type: 'annual',
      startDate: '2024-02-15',
      endDate: '2024-02-20',
      days: 5,
      reason: 'Family vacation',
      status: 'pending',
      appliedAt: '2024-01-15T10:00:00Z',
      approverId: null,
      processedAt: null,
      comments: ''
    },
    {
      id: '2',
      employeeId: 'EMP002',
      employeeName: 'Sarah Johnson',
      department: 'HR',
      type: 'sick',
      startDate: '2024-01-20',
      endDate: '2024-01-22',
      days: 3,
      reason: 'Medical treatment',
      status: 'approved',
      appliedAt: '2024-01-18T09:00:00Z',
      approverId: 'EMP003',
      processedAt: '2024-01-18T14:00:00Z',
      comments: 'Approved with medical certificate'
    },
    {
      id: '3',
      employeeId: 'EMP004',
      employeeName: 'Mike Chen',
      department: 'Marketing',
      type: 'annual',
      startDate: '2024-01-10',
      endDate: '2024-01-12',
      days: 3,
      reason: 'Personal matters',
      status: 'rejected',
      appliedAt: '2024-01-05T11:00:00Z',
      approverId: 'EMP003',
      processedAt: '2024-01-06T16:00:00Z',
      comments: 'Insufficient notice period'
    }
  ];

  const leaveBalance = {
    annual: { total: 25, used: 8, remaining: 17 },
    sick: { total: 10, used: 3, remaining: 7 },
    maternity: { total: 90, used: 0, remaining: 90 },
    paternity: { total: 15, used: 0, remaining: 15 },
    emergency: { total: 5, used: 1, remaining: 4 }
  };

  const holidays = [
    { date: '2024-01-01', name: 'New Year\'s Day', country: 'Global' },
    { date: '2024-07-04', name: 'Independence Day', country: 'USA' },
    { date: '2024-12-25', name: 'Christmas Day', country: 'Global' },
    { date: '2024-03-21', name: 'Nowruz', country: 'Iran' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'rejected': return <XCircle className="w-4 h-4 text-red-600" />;
      case 'pending': return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      default: return <Clock className="w-4 h-4 text-gray-600" />;
    }
  };

  const filteredRequests = mockLeaveRequests.filter(request => 
    selectedStatus === 'all' || request.status === selectedStatus
  );

  const ApplyLeaveModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-md">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Apply for Leave</h3>
        <form className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Leave Type</label>
            <select className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500">
              <option value="annual">Annual Leave</option>
              <option value="sick">Sick Leave</option>
              <option value="maternity">Maternity Leave</option>
              <option value="paternity">Paternity Leave</option>
              <option value="emergency">Emergency Leave</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
              <input type="date" className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
              <input type="date" className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Reason</label>
            <textarea 
              rows={3} 
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
              placeholder="Please provide a reason for your leave request..."
            />
          </div>
          <div className="flex space-x-3 pt-4">
            <button 
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Submit Request
            </button>
            <button 
              type="button"
              onClick={() => setShowApplyModal(false)}
              className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{t('leaves.title')}</h1>
          <p className="text-gray-600 mt-1">Manage leave requests and track balances</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button 
            onClick={() => setShowApplyModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>{t('leaves.apply')}</span>
          </button>
          <button className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition-colors">
            <Download size={20} />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { key: 'requests', label: 'Leave Requests' },
              { key: 'balance', label: 'Leave Balance' },
              { key: 'calendar', label: 'Holiday Calendar' }
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as any)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.key
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'requests' && (
            <div className="space-y-6">
              {/* Filters */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Filter size={20} className="text-gray-400" />
                    <select
                      value={selectedStatus}
                      onChange={(e) => setSelectedStatus(e.target.value)}
                      className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="all">All Status</option>
                      <option value="pending">Pending</option>
                      <option value="approved">Approved</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>
                </div>
                <div className="text-sm text-gray-600">
                  {filteredRequests.length} request{filteredRequests.length !== 1 ? 's' : ''}
                </div>
              </div>

              {/* Requests List */}
              <div className="space-y-4">
                {filteredRequests.map((request) => (
                  <div key={request.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium text-white">
                            {request.employeeName.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{request.employeeName}</h4>
                          <p className="text-sm text-gray-500">{request.department}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(request.status)}
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(request.status)}`}>
                          {request.status}
                        </span>
                      </div>
                    </div>
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">Type:</span>
                        <span className="ml-1 font-medium capitalize">{request.type}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Duration:</span>
                        <span className="ml-1 font-medium">
                          {format(parseISO(request.startDate), 'MMM d')} - {format(parseISO(request.endDate), 'MMM d')}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500">Days:</span>
                        <span className="ml-1 font-medium">{request.days}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Applied:</span>
                        <span className="ml-1 font-medium">{format(parseISO(request.appliedAt), 'MMM d, yyyy')}</span>
                      </div>
                    </div>
                    <div className="mt-2">
                      <span className="text-gray-500 text-sm">Reason:</span>
                      <span className="ml-1 text-sm">{request.reason}</span>
                    </div>
                    {hasPermission('leaves.approve') && request.status === 'pending' && (
                      <div className="mt-4 flex space-x-2">
                        <button className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm">
                          Approve
                        </button>
                        <button className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm">
                          Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'balance' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-gray-900">Leave Balance Overview</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Object.entries(leaveBalance).map(([type, balance]) => (
                  <div key={type} className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
                    <h4 className="font-medium text-gray-900 capitalize mb-4">{type} Leave</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Total Allocated:</span>
                        <span className="font-medium">{balance.total} days</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Used:</span>
                        <span className="font-medium text-red-600">{balance.used} days</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Remaining:</span>
                        <span className="font-medium text-green-600">{balance.remaining} days</span>
                      </div>
                      <div className="mt-3">
                        <div className="bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${(balance.used / balance.total) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'calendar' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-gray-900">Holiday Calendar</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {holidays.map((holiday, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                    <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-red-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">{holiday.name}</h4>
                      <p className="text-sm text-gray-500">{format(parseISO(holiday.date), 'EEEE, MMMM d, yyyy')}</p>
                      <p className="text-xs text-gray-400">{holiday.country}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {showApplyModal && <ApplyLeaveModal />}
    </div>
  );
};

export default LeaveManagement;