import React, { useState } from 'react';
import { Users, Plus, Edit, Trash2, Eye, Search, Filter, Shield, UserCheck, UserX, Save, X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { format, parseISO } from 'date-fns';

interface User {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  department: string;
  position: string;
  status: 'active' | 'inactive' | 'suspended';
  lastLogin: string | null;
  createdAt: string;
  avatar: string;
  permissions: string[];
}

interface Role {
  id: string;
  name: string;
  displayName: string;
  description: string;
  permissions: string[];
  userCount: number;
  createdAt: string;
  color: string;
}

interface Permission {
  id: string;
  name: string;
  module: string;
  description: string;
  category: 'read' | 'write' | 'delete' | 'approve';
}

const UserManagement: React.FC = () => {
  const { t } = useLanguage();
  const { user, hasPermission } = useAuth();
  const [activeTab, setActiveTab] = useState<'users' | 'roles' | 'permissions'>('users');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');
  const [showUserModal, setShowUserModal] = useState(false);
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedRoleForEdit, setSelectedRoleForEdit] = useState<Role | null>(null);
  const [editingUser, setEditingUser] = useState<Partial<User>>({});
  const [editingRole, setEditingRole] = useState<Partial<Role>>({});

  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      username: 'admin',
      email: 'admin@company.com',
      firstName: 'System',
      lastName: 'Administrator',
      role: 'admin',
      department: 'IT',
      position: 'System Administrator',
      status: 'active',
      lastLogin: '2024-01-15T09:00:00Z',
      createdAt: '2024-01-01T00:00:00Z',
      avatar: 'SA',
      permissions: ['*']
    },
    {
      id: '2',
      username: 'hr.manager',
      email: 'hr@company.com',
      firstName: 'Sarah',
      lastName: 'Johnson',
      role: 'hr_manager',
      department: 'Human Resources',
      position: 'HR Manager',
      status: 'active',
      lastLogin: '2024-01-15T08:30:00Z',
      createdAt: '2024-01-01T00:00:00Z',
      avatar: 'SJ',
      permissions: ['employees.*', 'attendance.*', 'leaves.*', 'payroll.*']
    },
    {
      id: '3',
      username: 'dept.head',
      email: 'manager@company.com',
      firstName: 'Emily',
      lastName: 'Chen',
      role: 'department_head',
      department: 'Engineering',
      position: 'Engineering Manager',
      status: 'active',
      lastLogin: '2024-01-15T08:00:00Z',
      createdAt: '2024-01-01T00:00:00Z',
      avatar: 'EC',
      permissions: ['employees.view', 'attendance.view', 'leaves.approve', 'performance.*']
    },
    {
      id: '4',
      username: 'john.doe',
      email: 'employee@company.com',
      firstName: 'John',
      lastName: 'Doe',
      role: 'employee',
      department: 'Engineering',
      position: 'Software Developer',
      status: 'active',
      lastLogin: '2024-01-15T07:45:00Z',
      createdAt: '2024-01-01T00:00:00Z',
      avatar: 'JD',
      permissions: ['profile.view', 'profile.edit', 'attendance.view', 'leaves.create']
    }
  ]);

  const [roles, setRoles] = useState<Role[]>([
    {
      id: '1',
      name: 'admin',
      displayName: 'System Administrator',
      description: 'Full system access with all permissions',
      permissions: ['*'],
      userCount: 1,
      createdAt: '2024-01-01T00:00:00Z',
      color: 'bg-red-100 text-red-800'
    },
    {
      id: '2',
      name: 'hr_manager',
      displayName: 'HR Manager',
      description: 'Human resources management with employee and payroll access',
      permissions: ['employees.*', 'attendance.*', 'leaves.*', 'payroll.*', 'recruitment.*', 'training.*'],
      userCount: 3,
      createdAt: '2024-01-01T00:00:00Z',
      color: 'bg-blue-100 text-blue-800'
    },
    {
      id: '3',
      name: 'department_head',
      displayName: 'Department Head',
      description: 'Department management with team oversight capabilities',
      permissions: ['employees.view', 'attendance.view', 'leaves.approve', 'performance.*'],
      userCount: 8,
      createdAt: '2024-01-01T00:00:00Z',
      color: 'bg-purple-100 text-purple-800'
    },
    {
      id: '4',
      name: 'employee',
      displayName: 'Employee',
      description: 'Basic employee access for personal data and requests',
      permissions: ['profile.view', 'profile.edit', 'attendance.view', 'leaves.create', 'performance.view'],
      userCount: 245,
      createdAt: '2024-01-01T00:00:00Z',
      color: 'bg-green-100 text-green-800'
    }
  ]);

  const mockPermissions: Permission[] = [
    { id: '1', name: 'employees.view', module: 'Employees', description: 'View employee profiles and directory', category: 'read' },
    { id: '2', name: 'employees.create', module: 'Employees', description: 'Create new employee profiles', category: 'write' },
    { id: '3', name: 'employees.edit', module: 'Employees', description: 'Edit existing employee profiles', category: 'write' },
    { id: '4', name: 'employees.delete', module: 'Employees', description: 'Delete employee profiles', category: 'delete' },
    { id: '5', name: 'attendance.view', module: 'Attendance', description: 'View attendance records', category: 'read' },
    { id: '6', name: 'attendance.manage', module: 'Attendance', description: 'Manage attendance records and settings', category: 'write' },
    { id: '7', name: 'leaves.view', module: 'Leave Management', description: 'View leave requests and balances', category: 'read' },
    { id: '8', name: 'leaves.create', module: 'Leave Management', description: 'Create leave requests', category: 'write' },
    { id: '9', name: 'leaves.approve', module: 'Leave Management', description: 'Approve or reject leave requests', category: 'approve' },
    { id: '10', name: 'payroll.view', module: 'Payroll', description: 'View payroll information', category: 'read' },
    { id: '11', name: 'payroll.process', module: 'Payroll', description: 'Process payroll and generate payslips', category: 'write' },
    { id: '12', name: 'performance.view', module: 'Performance', description: 'View performance reviews and goals', category: 'read' },
    { id: '13', name: 'performance.manage', module: 'Performance', description: 'Manage performance reviews and evaluations', category: 'write' },
    { id: '14', name: 'recruitment.view', module: 'Recruitment', description: 'View job postings and applications', category: 'read' },
    { id: '15', name: 'recruitment.manage', module: 'Recruitment', description: 'Manage recruitment process and applications', category: 'write' },
    { id: '16', name: 'training.view', module: 'Training', description: 'View training courses and progress', category: 'read' },
    { id: '17', name: 'training.manage', module: 'Training', description: 'Manage training programs and assignments', category: 'write' },
    { id: '18', name: 'reports.view', module: 'Reports', description: 'View and generate reports', category: 'read' },
    { id: '19', name: 'settings.view', module: 'Settings', description: 'View system settings', category: 'read' },
    { id: '20', name: 'settings.manage', module: 'Settings', description: 'Manage system settings and configuration', category: 'write' }
  ];

  // Helper functions
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-red-100 text-red-800';
      case 'suspended': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'read': return 'bg-blue-100 text-blue-800';
      case 'write': return 'bg-green-100 text-green-800';
      case 'delete': return 'bg-red-100 text-red-800';
      case 'approve': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const generateAvatar = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };

  const generateId = () => {
    return Math.random().toString(36).substr(2, 9);
  };

  // User CRUD operations
  const handleCreateUser = (userData: Partial<User>) => {
    const newUser: User = {
      id: generateId(),
      username: userData.username || '',
      email: userData.email || '',
      firstName: userData.firstName || '',
      lastName: userData.lastName || '',
      role: userData.role || 'employee',
      department: userData.department || '',
      position: userData.position || '',
      status: 'active',
      lastLogin: null,
      createdAt: new Date().toISOString(),
      avatar: generateAvatar(userData.firstName || '', userData.lastName || ''),
      permissions: roles.find(r => r.name === userData.role)?.permissions || []
    };

    setUsers([...users, newUser]);
    setShowUserModal(false);
    setEditingUser({});
    
    // Update role user count
    setRoles(roles.map(role => 
      role.name === newUser.role 
        ? { ...role, userCount: role.userCount + 1 }
        : role
    ));
  };

  const handleUpdateUser = (userData: Partial<User>) => {
    if (!selectedUser) return;

    const updatedUser = {
      ...selectedUser,
      ...userData,
      avatar: generateAvatar(userData.firstName || selectedUser.firstName, userData.lastName || selectedUser.lastName)
    };

    setUsers(users.map(u => u.id === selectedUser.id ? updatedUser : u));
    setShowUserModal(false);
    setSelectedUser(null);
    setEditingUser({});
  };

  const handleDeleteUser = (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      const userToDelete = users.find(u => u.id === userId);
      setUsers(users.filter(u => u.id !== userId));
      
      // Update role user count
      if (userToDelete) {
        setRoles(roles.map(role => 
          role.name === userToDelete.role 
            ? { ...role, userCount: Math.max(0, role.userCount - 1) }
            : role
        ));
      }
    }
  };

  const handleToggleUserStatus = (userId: string) => {
    setUsers(users.map(u => 
      u.id === userId 
        ? { ...u, status: u.status === 'active' ? 'suspended' : 'active' as 'active' | 'inactive' | 'suspended' }
        : u
    ));
  };

  const handleViewUser = (user: User) => {
    setSelectedUser(user);
    setShowViewModal(true);
  };

  const handleEditUser = (user: User) => {
    setSelectedUser(user);
    setEditingUser(user);
    setShowUserModal(true);
  };

  // Role CRUD operations
  const handleCreateRole = (roleData: Partial<Role>) => {
    const newRole: Role = {
      id: generateId(),
      name: roleData.name || '',
      displayName: roleData.displayName || '',
      description: roleData.description || '',
      permissions: roleData.permissions || [],
      userCount: 0,
      createdAt: new Date().toISOString(),
      color: 'bg-gray-100 text-gray-800'
    };

    setRoles([...roles, newRole]);
    setShowRoleModal(false);
    setEditingRole({});
  };

  const handleUpdateRole = (roleData: Partial<Role>) => {
    if (!selectedRoleForEdit) return;

    const updatedRole = {
      ...selectedRoleForEdit,
      ...roleData
    };

    setRoles(roles.map(r => r.id === selectedRoleForEdit.id ? updatedRole : r));
    setShowRoleModal(false);
    setSelectedRoleForEdit(null);
    setEditingRole({});
  };

  const handleDeleteRole = (roleId: string) => {
    const role = roles.find(r => r.id === roleId);
    if (role && role.userCount > 0) {
      alert('Cannot delete role with assigned users. Please reassign users first.');
      return;
    }

    if (window.confirm('Are you sure you want to delete this role?')) {
      setRoles(roles.filter(r => r.id !== roleId));
    }
  };

  const handleEditRole = (role: Role) => {
    setSelectedRoleForEdit(role);
    setEditingRole(role);
    setShowRoleModal(true);
  };

  // Filter users
  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.username.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = selectedRole === 'all' || user.role === selectedRole;
    
    return matchesSearch && matchesRole;
  });

  // Modal Components
  const UserModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">
            {selectedUser ? 'Edit User' : 'Create New User'}
          </h3>
          <button 
            onClick={() => {
              setShowUserModal(false);
              setSelectedUser(null);
              setEditingUser({});
            }}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={(e) => {
          e.preventDefault();
          if (selectedUser) {
            handleUpdateUser(editingUser);
          } else {
            handleCreateUser(editingUser);
          }
        }} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
              <input 
                type="text" 
                value={editingUser.username || ''}
                onChange={(e) => setEditingUser({...editingUser, username: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="john.doe"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input 
                type="email" 
                value={editingUser.email || ''}
                onChange={(e) => setEditingUser({...editingUser, email: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="john.doe@company.com"
                required
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
              <input 
                type="text" 
                value={editingUser.firstName || ''}
                onChange={(e) => setEditingUser({...editingUser, firstName: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="John"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
              <input 
                type="text" 
                value={editingUser.lastName || ''}
                onChange={(e) => setEditingUser({...editingUser, lastName: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="Doe"
                required
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
              <select 
                value={editingUser.role || ''}
                onChange={(e) => setEditingUser({...editingUser, role: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Role</option>
                {roles.map(role => (
                  <option key={role.id} value={role.name}>{role.displayName}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
              <select 
                value={editingUser.department || ''}
                onChange={(e) => setEditingUser({...editingUser, department: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Department</option>
                <option value="Engineering">Engineering</option>
                <option value="Human Resources">Human Resources</option>
                <option value="Marketing">Marketing</option>
                <option value="Sales">Sales</option>
                <option value="Finance">Finance</option>
                <option value="IT">IT</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Position</label>
            <input 
              type="text" 
              value={editingUser.position || ''}
              onChange={(e) => setEditingUser({...editingUser, position: e.target.value})}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
              placeholder="Software Developer"
              required
            />
          </div>
          <div className="flex space-x-3 pt-4">
            <button 
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2"
            >
              <Save size={16} />
              <span>{selectedUser ? 'Update User' : 'Create User'}</span>
            </button>
            <button 
              type="button"
              onClick={() => {
                setShowUserModal(false);
                setSelectedUser(null);
                setEditingUser({});
              }}
              className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  const ViewUserModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">User Details</h3>
          <button 
            onClick={() => {
              setShowViewModal(false);
              setSelectedUser(null);
            }}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={20} />
          </button>
        </div>
        
        {selectedUser && (
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-xl font-medium text-white">{selectedUser.avatar}</span>
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900">
                  {selectedUser.firstName} {selectedUser.lastName}
                </h4>
                <p className="text-gray-600">{selectedUser.position}</p>
                <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(selectedUser.status)}`}>
                  {selectedUser.status}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h5 className="font-medium text-gray-900 mb-3">Basic Information</h5>
                <div className="space-y-2">
                  <div>
                    <span className="text-sm text-gray-500">Username:</span>
                    <span className="ml-2 text-sm text-gray-900">{selectedUser.username}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-500">Email:</span>
                    <span className="ml-2 text-sm text-gray-900">{selectedUser.email}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-500">Department:</span>
                    <span className="ml-2 text-sm text-gray-900">{selectedUser.department}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-500">Role:</span>
                    <span className="ml-2 text-sm text-gray-900">
                      {roles.find(r => r.name === selectedUser.role)?.displayName || selectedUser.role}
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <h5 className="font-medium text-gray-900 mb-3">Account Information</h5>
                <div className="space-y-2">
                  <div>
                    <span className="text-sm text-gray-500">Created:</span>
                    <span className="ml-2 text-sm text-gray-900">
                      {format(parseISO(selectedUser.createdAt), 'MMM d, yyyy')}
                    </span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-500">Last Login:</span>
                    <span className="ml-2 text-sm text-gray-900">
                      {selectedUser.lastLogin ? format(parseISO(selectedUser.lastLogin), 'MMM d, yyyy HH:mm') : 'Never'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h5 className="font-medium text-gray-900 mb-3">Permissions</h5>
              <div className="flex flex-wrap gap-2">
                {selectedUser.permissions.map((permission, index) => (
                  <span key={index} className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded">
                    {permission}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex space-x-3 pt-4">
              <button 
                onClick={() => {
                  setShowViewModal(false);
                  handleEditUser(selectedUser);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors flex items-center space-x-2"
              >
                <Edit size={16} />
                <span>Edit User</span>
              </button>
              <button 
                onClick={() => {
                  setShowViewModal(false);
                  setSelectedUser(null);
                }}
                className="bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const RoleModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">
            {selectedRoleForEdit ? 'Edit Role' : 'Create New Role'}
          </h3>
          <button 
            onClick={() => {
              setShowRoleModal(false);
              setSelectedRoleForEdit(null);
              setEditingRole({});
            }}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={(e) => {
          e.preventDefault();
          if (selectedRoleForEdit) {
            handleUpdateRole(editingRole);
          } else {
            handleCreateRole(editingRole);
          }
        }} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Role Name</label>
              <input 
                type="text" 
                value={editingRole.name || ''}
                onChange={(e) => setEditingRole({...editingRole, name: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="team_lead"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Display Name</label>
              <input 
                type="text" 
                value={editingRole.displayName || ''}
                onChange={(e) => setEditingRole({...editingRole, displayName: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="Team Lead"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea 
              rows={3} 
              value={editingRole.description || ''}
              onChange={(e) => setEditingRole({...editingRole, description: e.target.value})}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
              placeholder="Describe the role and its responsibilities..."
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">Permissions</label>
            <div className="max-h-64 overflow-y-auto border border-gray-200 rounded-lg p-4">
              {Object.entries(
                mockPermissions.reduce((acc, permission) => {
                  if (!acc[permission.module]) acc[permission.module] = [];
                  acc[permission.module].push(permission);
                  return acc;
                }, {} as Record<string, Permission[]>)
              ).map(([module, permissions]) => (
                <div key={module} className="mb-4">
                  <h4 className="font-medium text-gray-900 mb-2">{module}</h4>
                  <div className="space-y-2">
                    {permissions.map(permission => (
                      <label key={permission.id} className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          checked={(editingRole.permissions || []).includes(permission.name)}
                          onChange={(e) => {
                            const currentPermissions = editingRole.permissions || [];
                            if (e.target.checked) {
                              setEditingRole({
                                ...editingRole, 
                                permissions: [...currentPermissions, permission.name]
                              });
                            } else {
                              setEditingRole({
                                ...editingRole, 
                                permissions: currentPermissions.filter(p => p !== permission.name)
                              });
                            }
                          }}
                          className="rounded border-gray-300" 
                        />
                        <span className="text-sm text-gray-700">{permission.description}</span>
                        <span className={`px-2 py-1 text-xs rounded-full ${getCategoryColor(permission.category)}`}>
                          {permission.category}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex space-x-3 pt-4">
            <button 
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2"
            >
              <Save size={16} />
              <span>{selectedRoleForEdit ? 'Update Role' : 'Create Role'}</span>
            </button>
            <button 
              type="button"
              onClick={() => {
                setShowRoleModal(false);
                setSelectedRoleForEdit(null);
                setEditingRole({});
              }}
              className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
          <p className="text-gray-600 mt-1">Manage users, roles, and permissions</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          {activeTab === 'users' && (
            <button 
              onClick={() => {
                setSelectedUser(null);
                setEditingUser({});
                setShowUserModal(true);
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
            >
              <Plus size={20} />
              <span>Add User</span>
            </button>
          )}
          {activeTab === 'roles' && (
            <button 
              onClick={() => {
                setSelectedRoleForEdit(null);
                setEditingRole({});
                setShowRoleModal(true);
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
            >
              <Plus size={20} />
              <span>Add Role</span>
            </button>
          )}
          <button className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition-colors">
            Export Data
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { key: 'users', label: 'Users', icon: Users },
              { key: 'roles', label: 'Roles', icon: Shield },
              { key: 'permissions', label: 'Permissions', icon: UserCheck }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.key
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'users' && (
            <div className="space-y-6">
              {/* Search and Filters */}
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                <div className="flex-1 max-w-md">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="text"
                      placeholder="Search users..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Filter size={20} className="text-gray-400" />
                    <select
                      value={selectedRole}
                      onChange={(e) => setSelectedRole(e.target.value)}
                      className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="all">All Roles</option>
                      {roles.map(role => (
                        <option key={role.id} value={role.name}>{role.displayName}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Users Table */}
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        User
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Role
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Department
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Last Login
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-white">{user.avatar}</span>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {user.firstName} {user.lastName}
                              </div>
                              <div className="text-sm text-gray-500">{user.email}</div>
                              <div className="text-sm text-gray-500">@{user.username}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                            roles.find(r => r.name === user.role)?.color || 'bg-gray-100 text-gray-800'
                          }`}>
                            {roles.find(r => r.name === user.role)?.displayName || user.role}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          <div>
                            <div className="font-medium">{user.department}</div>
                            <div className="text-gray-500">{user.position}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(user.status)}`}>
                            {user.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {user.lastLogin ? format(parseISO(user.lastLogin), 'MMM d, yyyy HH:mm') : 'Never'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center space-x-2">
                            <button 
                              onClick={() => handleViewUser(user)}
                              className="text-blue-600 hover:text-blue-900 p-1 hover:bg-blue-50 rounded"
                              title="View User"
                            >
                              <Eye size={16} />
                            </button>
                            <button 
                              onClick={() => handleEditUser(user)}
                              className="text-gray-600 hover:text-gray-900 p-1 hover:bg-gray-50 rounded"
                              title="Edit User"
                            >
                              <Edit size={16} />
                            </button>
                            <button 
                              onClick={() => handleDeleteUser(user.id)}
                              className="text-red-600 hover:text-red-900 p-1 hover:bg-red-50 rounded"
                              title="Delete User"
                            >
                              <Trash2 size={16} />
                            </button>
                            <button 
                              onClick={() => handleToggleUserStatus(user.id)}
                              className="text-yellow-600 hover:text-yellow-900 p-1 hover:bg-yellow-50 rounded"
                              title={user.status === 'active' ? 'Suspend User' : 'Activate User'}
                            >
                              <UserX size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'roles' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">System Roles</h3>
                <div className="text-sm text-gray-600">
                  {roles.length} role{roles.length !== 1 ? 's' : ''}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {roles.map((role) => (
                  <div key={role.id} className="border border-gray-200 rounded-lg p-6 hover:bg-gray-50">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h4 className="font-medium text-gray-900">{role.displayName}</h4>
                          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${role.color}`}>
                            {role.name}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{role.description}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>{role.userCount} users</span>
                          <span>{role.permissions.length} permissions</span>
                          <span>Created {format(parseISO(role.createdAt), 'MMM d, yyyy')}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => handleEditRole(role)}
                          className="text-gray-600 hover:text-gray-900 p-1 hover:bg-gray-50 rounded"
                          title="Edit Role"
                        >
                          <Edit size={16} />
                        </button>
                        {role.name !== 'admin' && (
                          <button 
                            onClick={() => handleDeleteRole(role.id)}
                            className="text-red-600 hover:text-red-900 p-1 hover:bg-red-50 rounded"
                            title="Delete Role"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </div>
                    <div>
                      <h5 className="font-medium text-gray-900 mb-2">Permissions</h5>
                      <div className="flex flex-wrap gap-1">
                        {role.permissions.slice(0, 3).map((permission, index) => (
                          <span key={index} className="px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded">
                            {permission}
                          </span>
                        ))}
                        {role.permissions.length > 3 && (
                          <span className="px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded">
                            +{role.permissions.length - 3} more
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'permissions' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">System Permissions</h3>
                <div className="text-sm text-gray-600">
                  {mockPermissions.length} permission{mockPermissions.length !== 1 ? 's' : ''}
                </div>
              </div>

              <div className="space-y-6">
                {Object.entries(
                  mockPermissions.reduce((acc, permission) => {
                    if (!acc[permission.module]) acc[permission.module] = [];
                    acc[permission.module].push(permission);
                    return acc;
                  }, {} as Record<string, Permission[]>)
                ).map(([module, permissions]) => (
                  <div key={module} className="bg-white border border-gray-200 rounded-lg p-6">
                    <h4 className="text-lg font-medium text-gray-900 mb-4">{module}</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {permissions.map((permission) => (
                        <div key={permission.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="font-medium text-gray-900">{permission.name}</span>
                              <span className={`px-2 py-1 text-xs rounded-full ${getCategoryColor(permission.category)}`}>
                                {permission.category}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600">{permission.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {showUserModal && <UserModal />}
      {showViewModal && <ViewUserModal />}
      {showRoleModal && <RoleModal />}
    </div>
  );
};

export default UserManagement;