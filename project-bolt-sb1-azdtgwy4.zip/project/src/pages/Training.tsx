import React, { useState } from 'react';
import { GraduationCap, BookOpen, Award, Users, Plus, Eye, Play, CheckCircle, Clock } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { format, parseISO } from 'date-fns';

const Training: React.FC = () => {
  const { t } = useLanguage();
  const { user, hasPermission } = useAuth();
  const [activeTab, setActiveTab] = useState<'courses' | 'skills' | 'certifications' | 'progress'>('courses');
  const [showCourseModal, setShowCourseModal] = useState(false);

  const trainingStats = {
    totalCourses: 45,
    activeLearners: 234,
    completedCourses: 1250,
    certifications: 89,
    averageCompletion: 78,
    skillsTracked: 156
  };

  const mockCourses = [
    {
      id: '1',
      title: 'Advanced React Development',
      description: 'Master advanced React concepts including hooks, context, and performance optimization',
      category: 'Technical',
      level: 'Advanced',
      duration: 40,
      instructor: 'Sarah Johnson',
      enrollments: 45,
      completions: 32,
      rating: 4.8,
      status: 'active',
      createdAt: '2024-01-10T00:00:00Z',
      modules: [
        { title: 'React Hooks Deep Dive', duration: 8, completed: true },
        { title: 'Context API & State Management', duration: 10, completed: true },
        { title: 'Performance Optimization', duration: 12, completed: false },
        { title: 'Testing React Applications', duration: 10, completed: false }
      ]
    },
    {
      id: '2',
      title: 'Leadership Fundamentals',
      description: 'Essential leadership skills for new managers and team leads',
      category: 'Leadership',
      level: 'Intermediate',
      duration: 24,
      instructor: 'Michael Chen',
      enrollments: 28,
      completions: 22,
      rating: 4.6,
      status: 'active',
      createdAt: '2024-01-05T00:00:00Z',
      modules: [
        { title: 'Communication Skills', duration: 6, completed: true },
        { title: 'Team Building', duration: 8, completed: false },
        { title: 'Conflict Resolution', duration: 6, completed: false },
        { title: 'Performance Management', duration: 4, completed: false }
      ]
    },
    {
      id: '3',
      title: 'Data Privacy & GDPR Compliance',
      description: 'Understanding data protection regulations and compliance requirements',
      category: 'Compliance',
      level: 'Beginner',
      duration: 16,
      instructor: 'Emily Davis',
      enrollments: 156,
      completions: 134,
      rating: 4.4,
      status: 'active',
      createdAt: '2023-12-15T00:00:00Z',
      modules: [
        { title: 'GDPR Overview', duration: 4, completed: true },
        { title: 'Data Processing Principles', duration: 6, completed: true },
        { title: 'Rights of Data Subjects', duration: 4, completed: true },
        { title: 'Compliance Implementation', duration: 2, completed: true }
      ]
    }
  ];

  const mockSkills = [
    {
      id: '1',
      name: 'React Development',
      category: 'Frontend',
      employees: 45,
      averageLevel: 3.2,
      trending: 'up',
      courses: ['Advanced React Development', 'React Testing'],
      certifications: ['React Professional Certificate']
    },
    {
      id: '2',
      name: 'Project Management',
      category: 'Management',
      employees: 28,
      averageLevel: 2.8,
      trending: 'stable',
      courses: ['Agile Project Management', 'Scrum Master Certification'],
      certifications: ['PMP', 'Scrum Master']
    },
    {
      id: '3',
      name: 'Data Analysis',
      category: 'Analytics',
      employees: 32,
      averageLevel: 2.5,
      trending: 'up',
      courses: ['SQL Fundamentals', 'Data Visualization'],
      certifications: ['Google Analytics', 'Tableau Desktop']
    }
  ];

  const mockCertifications = [
    {
      id: '1',
      name: 'AWS Solutions Architect',
      provider: 'Amazon Web Services',
      employees: 12,
      expiryDate: '2025-06-15',
      status: 'active',
      cost: 300,
      renewalRequired: true
    },
    {
      id: '2',
      name: 'Scrum Master Certified',
      provider: 'Scrum Alliance',
      employees: 8,
      expiryDate: '2024-12-20',
      status: 'expiring_soon',
      cost: 250,
      renewalRequired: true
    },
    {
      id: '3',
      name: 'Google Analytics Individual Qualification',
      provider: 'Google',
      employees: 25,
      expiryDate: '2024-08-30',
      status: 'active',
      cost: 0,
      renewalRequired: false
    }
  ];

  const mockProgress = [
    {
      employeeId: 'EMP001',
      employeeName: 'John Doe',
      department: 'Engineering',
      coursesEnrolled: 3,
      coursesCompleted: 2,
      hoursSpent: 45,
      certificationsEarned: 1,
      currentCourse: 'Advanced React Development',
      progress: 75
    },
    {
      employeeId: 'EMP002',
      employeeName: 'Sarah Johnson',
      department: 'HR',
      coursesEnrolled: 2,
      coursesCompleted: 2,
      hoursSpent: 32,
      certificationsEarned: 2,
      currentCourse: null,
      progress: 100
    }
  ];

  const getLevelColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'beginner': return 'bg-green-100 text-green-800';
      case 'intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'technical': return 'bg-blue-100 text-blue-800';
      case 'leadership': return 'bg-purple-100 text-purple-800';
      case 'compliance': return 'bg-orange-100 text-orange-800';
      case 'soft skills': return 'bg-pink-100 text-pink-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'expiring_soon': return 'bg-yellow-100 text-yellow-800';
      case 'expired': return 'bg-red-100 text-red-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <span key={i} className={i < Math.floor(rating) ? 'text-yellow-400' : 'text-gray-300'}>
        ★
      </span>
    ));
  };

  const CourseModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Course</h3>
        <form className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Course Title</label>
            <input 
              type="text" 
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
              placeholder="e.g. Advanced JavaScript Concepts"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea 
              rows={3} 
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
              placeholder="Describe what learners will gain from this course..."
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
              <select className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500">
                <option>Technical</option>
                <option>Leadership</option>
                <option>Compliance</option>
                <option>Soft Skills</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Level</label>
              <select className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500">
                <option>Beginner</option>
                <option>Intermediate</option>
                <option>Advanced</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Duration (hours)</label>
              <input 
                type="number" 
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="24"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Instructor</label>
            <input 
              type="text" 
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
              placeholder="Instructor name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Course Modules</label>
            <div className="space-y-2">
              <div className="flex space-x-2">
                <input 
                  type="text" 
                  className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                  placeholder="Module title"
                />
                <input 
                  type="number" 
                  className="w-20 border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                  placeholder="Hours"
                />
                <button type="button" className="bg-blue-600 text-white px-3 py-2 rounded-lg">+</button>
              </div>
            </div>
          </div>
          <div className="flex space-x-3 pt-4">
            <button 
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Create Course
            </button>
            <button 
              type="button"
              onClick={() => setShowCourseModal(false)}
              className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{t('training.title')}</h1>
          <p className="text-gray-600 mt-1">Manage employee learning and development programs</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button 
            onClick={() => setShowCourseModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>New Course</span>
          </button>
          <button className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition-colors">
            Generate Report
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 rounded-lg">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Courses</p>
              <p className="text-2xl font-bold text-gray-900">{trainingStats.totalCourses}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-lg">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Learners</p>
              <p className="text-2xl font-bold text-gray-900">{trainingStats.activeLearners}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-purple-100 rounded-lg">
              <CheckCircle className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Completed</p>
              <p className="text-2xl font-bold text-gray-900">{trainingStats.completedCourses}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-yellow-100 rounded-lg">
              <Award className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Certifications</p>
              <p className="text-2xl font-bold text-gray-900">{trainingStats.certifications}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Clock className="w-6 h-6 text-indigo-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Completion</p>
              <p className="text-2xl font-bold text-gray-900">{trainingStats.averageCompletion}%</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-red-100 rounded-lg">
              <GraduationCap className="w-6 h-6 text-red-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Skills</p>
              <p className="text-2xl font-bold text-gray-900">{trainingStats.skillsTracked}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { key: 'courses', label: 'Training Courses', icon: BookOpen },
              { key: 'skills', label: 'Skills Tracking', icon: GraduationCap },
              { key: 'certifications', label: 'Certifications', icon: Award },
              { key: 'progress', label: 'Progress', icon: CheckCircle }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.key
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'courses' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Training Courses</h3>
                <div className="text-sm text-gray-600">
                  {mockCourses.length} course{mockCourses.length !== 1 ? 's' : ''}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {mockCourses.map((course) => (
                  <div key={course.id} className="border border-gray-200 rounded-lg p-6 hover:bg-gray-50">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h4 className="font-medium text-gray-900">{course.title}</h4>
                          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getCategoryColor(course.category)}`}>
                            {course.category}
                          </span>
                          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getLevelColor(course.level)}`}>
                            {course.level}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{course.description}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500 mb-3">
                          <span>{course.duration} hours</span>
                          <span>By {course.instructor}</span>
                          <div className="flex items-center space-x-1">
                            {renderStars(course.rating)}
                            <span>({course.rating})</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>{course.enrollments} enrolled</span>
                          <span>{course.completions} completed</span>
                          <span>{Math.round((course.completions / course.enrollments) * 100)}% completion rate</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button className="text-blue-600 hover:text-blue-900">
                          <Eye size={16} />
                        </button>
                        <button className="text-green-600 hover:text-green-900">
                          <Play size={16} />
                        </button>
                
                      </div>
                    </div>

                    {/* Course Modules */}
                    <div className="mt-4">
                      <h5 className="font-medium text-gray-900 mb-2">Course Modules</h5>
                      <div className="space-y-2">
                        {course.modules.map((module, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <div className="flex items-center space-x-2">
                              {module.completed ? (
                                <CheckCircle size={16} className="text-green-600" />
                              ) : (
                                <Clock size={16} className="text-gray-400" />
                              )}
                              <span className="text-sm text-gray-900">{module.title}</span>
                            </div>
                            <span className="text-sm text-gray-500">{module.duration}h</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'skills' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Skills Tracking</h3>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                  Add Skill
                </button>
              </div>

              <div className="space-y-4">
                {mockSkills.map((skill) => (
                  <div key={skill.id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h4 className="font-medium text-gray-900">{skill.name}</h4>
                          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getCategoryColor(skill.category)}`}>
                            {skill.category}
                          </span>
                          <div className="flex items-center space-x-1">
                            <span className={`text-sm ${
                              skill.trending === 'up' ? 'text-green-600' : 
                              skill.trending === 'down' ? 'text-red-600' : 'text-gray-600'
                            }`}>
                              {skill.trending === 'up' ? '↗' : skill.trending === 'down' ? '↘' : '→'}
                            </span>
                            <span className="text-sm text-gray-500">
                              {skill.trending === 'up' ? 'Trending' : skill.trending === 'down' ? 'Declining' : 'Stable'}
                            </span>
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-gray-500">Employees with skill:</span>
                            <span className="ml-1 font-medium">{skill.employees}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Average level:</span>
                            <span className="ml-1 font-medium">{skill.averageLevel}/5</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Related courses:</span>
                            <span className="ml-1 font-medium">{skill.courses.length}</span>
                          </div>
                        </div>
                        <div className="mt-3">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm text-gray-600">Skill Level Distribution</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${(skill.averageLevel / 5) * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'certifications' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Certifications</h3>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                  Add Certification
                </button>
              </div>

              <div className="space-y-4">
                {mockCertifications.map((cert) => (
                  <div key={cert.id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h4 className="font-medium text-gray-900">{cert.name}</h4>
                          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(cert.status)}`}>
                            {cert.status.replace('_', ' ')}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">Provider: {cert.provider}</p>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-gray-500">Certified employees:</span>
                            <span className="ml-1 font-medium">{cert.employees}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Expires:</span>
                            <span className="ml-1 font-medium">{format(parseISO(cert.expiryDate), 'MMM d, yyyy')}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Cost:</span>
                            <span className="ml-1 font-medium">${cert.cost}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Renewal:</span>
                            <span className="ml-1 font-medium">{cert.renewalRequired ? 'Required' : 'Not required'}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button className="text-blue-600 hover:text-blue-900">
                          <Eye size={16} />
                        </button>
                        {cert.status === 'expiring_soon' && (
                          <button className="bg-yellow-600 hover:bg-yellow-700 text-white px-3 py-1 rounded text-sm">
                            Renew
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'progress' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Learning Progress</h3>
                <div className="text-sm text-gray-600">
                  {mockProgress.length} learner{mockProgress.length !== 1 ? 's' : ''}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Employee
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Enrolled
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Completed
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Hours
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Certifications
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Current Course
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Progress
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {mockProgress.map((progress) => (
                      <tr key={progress.employeeId} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-white">
                                {progress.employeeName.split(' ').map(n => n[0]).join('')}
                              </span>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{progress.employeeName}</div>
                              <div className="text-sm text-gray-500">{progress.department}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {progress.coursesEnrolled}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {progress.coursesCompleted}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {progress.hoursSpent}h
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {progress.certificationsEarned}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {progress.currentCourse || 'None'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full" 
                                style={{ width: `${progress.progress}%` }}
                              />
                            </div>
                            <span className="text-sm text-gray-900">{progress.progress}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      {showCourseModal && <CourseModal />}
    </div>
  );
};

export default Training;