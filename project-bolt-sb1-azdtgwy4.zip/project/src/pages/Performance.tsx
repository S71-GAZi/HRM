import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { BarChart3, TrendingUp, Users, Target, Award, Calendar } from 'lucide-react';

export default function Performance() {
  const { t } = useLanguage();
  const { user } = useAuth();

  const performanceMetrics = [
    {
      title: 'Overall Performance',
      value: '87%',
      change: '+5%',
      trend: 'up',
      icon: TrendingUp,
      color: 'bg-green-500'
    },
    {
      title: 'Team Productivity',
      value: '92%',
      change: '+3%',
      trend: 'up',
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      title: 'Goals Achieved',
      value: '15/18',
      change: '+2',
      trend: 'up',
      icon: Target,
      color: 'bg-purple-500'
    },
    {
      title: 'Recognition Points',
      value: '1,247',
      change: '+156',
      trend: 'up',
      icon: Award,
      color: 'bg-orange-500'
    }
  ];

  const recentEvaluations = [
    {
      id: 1,
      employee: 'John Smith',
      position: 'Software Engineer',
      score: 4.5,
      date: '2024-01-15',
      status: 'Completed'
    },
    {
      id: 2,
      employee: 'Sarah Johnson',
      position: 'Product Manager',
      score: 4.8,
      date: '2024-01-12',
      status: 'Completed'
    },
    {
      id: 3,
      employee: 'Mike Davis',
      position: 'UX Designer',
      score: 4.2,
      date: '2024-01-10',
      status: 'In Progress'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Performance Management</h1>
          <p className="text-gray-600 mt-2">Track and manage employee performance metrics</p>
        </div>
        <div className="flex space-x-3">
          <button className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2">
            <Calendar className="w-4 h-4" />
            <span>Schedule Review</span>
          </button>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
            <BarChart3 className="w-4 h-4" />
            <span>Generate Report</span>
          </button>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {performanceMetrics.map((metric, index) => {
          const IconComponent = metric.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className={`${metric.color} p-3 rounded-lg`}>
                  <IconComponent className="w-6 h-6 text-white" />
                </div>
                <span className={`text-sm font-medium ${
                  metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {metric.change}
                </span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">{metric.value}</h3>
              <p className="text-gray-600 text-sm">{metric.title}</p>
            </div>
          );
        })}
      </div>

      {/* Performance Overview Chart */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Performance Trends</h2>
          <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option>Last 6 months</option>
            <option>Last 3 months</option>
            <option>Last month</option>
          </select>
        </div>
        <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500">Performance chart visualization would go here</p>
          </div>
        </div>
      </div>

      {/* Recent Evaluations */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Recent Performance Evaluations</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left py-3 px-6 font-medium text-gray-700">Employee</th>
                <th className="text-left py-3 px-6 font-medium text-gray-700">Position</th>
                <th className="text-left py-3 px-6 font-medium text-gray-700">Score</th>
                <th className="text-left py-3 px-6 font-medium text-gray-700">Date</th>
                <th className="text-left py-3 px-6 font-medium text-gray-700">Status</th>
                <th className="text-left py-3 px-6 font-medium text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {recentEvaluations.map((evaluation) => (
                <tr key={evaluation.id} className="hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <div className="font-medium text-gray-900">{evaluation.employee}</div>
                  </td>
                  <td className="py-4 px-6 text-gray-600">{evaluation.position}</td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-1">
                      <span className="font-medium text-gray-900">{evaluation.score}</span>
                      <span className="text-yellow-500">★</span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-gray-600">{evaluation.date}</td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                      evaluation.status === 'Completed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {evaluation.status}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <button className="text-blue-600 hover:text-blue-800 font-medium text-sm">
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Performance Goals */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Current Goals</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-medium text-gray-900">Increase Team Productivity</h4>
                <p className="text-sm text-gray-600">Target: 95% by Q2 2024</p>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-blue-600">92%</div>
                <div className="w-20 bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: '92%' }}></div>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-medium text-gray-900">Employee Satisfaction</h4>
                <p className="text-sm text-gray-600">Target: 4.5/5 rating</p>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-green-600">4.3</div>
                <div className="w-20 bg-gray-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: '86%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performers</h3>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-3 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200">
              <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center">
                <Award className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-gray-900">Sarah Johnson</h4>
                <p className="text-sm text-gray-600">Product Manager • 4.8/5</p>
              </div>
              <div className="text-yellow-600 font-bold">🥇</div>
            </div>
            <div className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
              <div className="w-10 h-10 bg-gray-400 rounded-full flex items-center justify-center">
                <Award className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-gray-900">John Smith</h4>
                <p className="text-sm text-gray-600">Software Engineer • 4.5/5</p>
              </div>
              <div className="text-gray-600 font-bold">🥈</div>
            </div>
            <div className="flex items-center space-x-4 p-3 bg-orange-50 rounded-lg">
              <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                <Award className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-gray-900">Mike Davis</h4>
                <p className="text-sm text-gray-600">UX Designer • 4.2/5</p>
              </div>
              <div className="text-orange-600 font-bold">🥉</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}