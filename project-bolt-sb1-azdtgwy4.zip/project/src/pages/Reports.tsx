import React, { useState } from 'react';
import { BarChart3, Download, Calendar, Filter, TrendingUp, Users, Clock, DollarSign } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';

const Reports: React.FC = () => {
  const { t } = useLanguage();
  const { user, hasPermission } = useAuth();
  const [selectedReport, setSelectedReport] = useState('attendance');
  const [dateRange, setDateRange] = useState('last_30_days');

  const reportTypes = [
    { id: 'attendance', name: 'Attendance Report', icon: Clock, description: 'Employee attendance patterns and trends' },
    { id: 'payroll', name: 'Payroll Report', icon: DollarSign, description: 'Salary, benefits, and compensation analysis' },
    { id: 'performance', name: 'Performance Report', icon: TrendingUp, description: 'Employee performance metrics and reviews' },
    { id: 'headcount', name: 'Headcount Report', icon: Users, description: 'Employee demographics and distribution' },
    { id: 'training', name: 'Training Report', icon: BarChart3, description: 'Learning and development progress' },
    { id: 'turnover', name: 'Turnover Report', icon: TrendingUp, description: 'Employee retention and turnover analysis' }
  ];

  // Mock data for different reports
  const attendanceData = [
    { month: 'Jan', present: 92, absent: 8, late: 5 },
    { month: 'Feb', present: 94, absent: 6, late: 4 },
    { month: 'Mar', present: 91, absent: 9, late: 6 },
    { month: 'Apr', present: 95, absent: 5, late: 3 },
    { month: 'May', present: 93, absent: 7, late: 4 },
    { month: 'Jun', present: 96, absent: 4, late: 2 }
  ];

  const payrollData = [
    { department: 'Engineering', totalCost: 850000, employees: 45, avgSalary: 95000 },
    { department: 'Sales', totalCost: 420000, employees: 28, avgSalary: 75000 },
    { department: 'Marketing', totalCost: 320000, employees: 18, avgSalary: 70000 },
    { department: 'HR', totalCost: 180000, employees: 8, avgSalary: 65000 },
    { department: 'Finance', totalCost: 240000, employees: 12, avgSalary: 80000 }
  ];

  const performanceData = [
    { rating: '5.0', count: 45, percentage: 18 },
    { rating: '4.0-4.9', count: 120, percentage: 48 },
    { rating: '3.0-3.9', count: 65, percentage: 26 },
    { rating: '2.0-2.9', count: 15, percentage: 6 },
    { rating: '1.0-1.9', count: 5, percentage: 2 }
  ];

  const headcountData = [
    { department: 'Engineering', count: 45, color: '#3B82F6' },
    { department: 'Sales', count: 28, color: '#10B981' },
    { department: 'Marketing', count: 18, color: '#F59E0B' },
    { department: 'HR', count: 8, color: '#EF4444' },
    { department: 'Finance', count: 12, color: '#8B5CF6' },
    { department: 'Operations', count: 15, color: '#06B6D4' }
  ];

  const trainingData = [
    { month: 'Jan', completed: 45, enrolled: 60, hours: 320 },
    { month: 'Feb', completed: 52, enrolled: 65, hours: 380 },
    { month: 'Mar', completed: 48, enrolled: 70, hours: 420 },
    { month: 'Apr', completed: 58, enrolled: 75, hours: 450 },
    { month: 'May', completed: 62, enrolled: 80, hours: 520 },
    { month: 'Jun', completed: 68, enrolled: 85, hours: 580 }
  ];

  const turnoverData = [
    { month: 'Jan', hires: 8, departures: 3, retention: 97.2 },
    { month: 'Feb', hires: 12, departures: 5, retention: 96.8 },
    { month: 'Mar', hires: 6, departures: 7, retention: 96.1 },
    { month: 'Apr', hires: 15, departures: 4, retention: 96.5 },
    { month: 'May', hires: 9, departures: 6, retention: 96.2 },
    { month: 'Jun', hires: 11, departures: 2, retention: 96.8 }
  ];

  const generateReport = () => {
    // Mock report generation
    console.log(`Generating ${selectedReport} report for ${dateRange}`);
  };

  const exportReport = (format: string) => {
    // Mock export functionality
    console.log(`Exporting ${selectedReport} report as ${format}`);
  };

  const renderReportContent = () => {
    switch (selectedReport) {
      case 'attendance':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-green-50 rounded-lg p-6">
                <h4 className="font-medium text-green-900 mb-2">Average Attendance</h4>
                <p className="text-3xl font-bold text-green-600">94.2%</p>
                <p className="text-sm text-green-600 mt-1">+2.1% from last period</p>
              </div>
              <div className="bg-red-50 rounded-lg p-6">
                <h4 className="font-medium text-red-900 mb-2">Absence Rate</h4>
                <p className="text-3xl font-bold text-red-600">5.8%</p>
                <p className="text-sm text-red-600 mt-1">-1.2% from last period</p>
              </div>
              <div className="bg-yellow-50 rounded-lg p-6">
                <h4 className="font-medium text-yellow-900 mb-2">Late Arrivals</h4>
                <p className="text-3xl font-bold text-yellow-600">4.0%</p>
                <p className="text-sm text-yellow-600 mt-1">-0.5% from last period</p>
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h4 className="font-medium text-gray-900 mb-4">Attendance Trends</h4>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={attendanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="present" stackId="1" stroke="#10B981" fill="#10B981" />
                  <Area type="monotone" dataKey="absent" stackId="1" stroke="#EF4444" fill="#EF4444" />
                  <Area type="monotone" dataKey="late" stackId="1" stroke="#F59E0B" fill="#F59E0B" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        );

      case 'payroll':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-blue-50 rounded-lg p-6">
                <h4 className="font-medium text-blue-900 mb-2">Total Payroll</h4>
                <p className="text-3xl font-bold text-blue-600">$2.01M</p>
                <p className="text-sm text-blue-600 mt-1">Monthly cost</p>
              </div>
              <div className="bg-green-50 rounded-lg p-6">
                <h4 className="font-medium text-green-900 mb-2">Average Salary</h4>
                <p className="text-3xl font-bold text-green-600">$81,000</p>
                <p className="text-sm text-green-600 mt-1">Across all departments</p>
              </div>
              <div className="bg-purple-50 rounded-lg p-6">
                <h4 className="font-medium text-purple-900 mb-2">Benefits Cost</h4>
                <p className="text-3xl font-bold text-purple-600">$320K</p>
                <p className="text-sm text-purple-600 mt-1">16% of total payroll</p>
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h4 className="font-medium text-gray-900 mb-4">Payroll by Department</h4>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={payrollData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="department" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Total Cost']} />
                  <Bar dataKey="totalCost" fill="#3B82F6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        );

      case 'performance':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-yellow-50 rounded-lg p-6">
                <h4 className="font-medium text-yellow-900 mb-2">Average Rating</h4>
                <p className="text-3xl font-bold text-yellow-600">4.1/5</p>
                <p className="text-sm text-yellow-600 mt-1">Company-wide average</p>
              </div>
              <div className="bg-green-50 rounded-lg p-6">
                <h4 className="font-medium text-green-900 mb-2">Top Performers</h4>
                <p className="text-3xl font-bold text-green-600">18%</p>
                <p className="text-sm text-green-600 mt-1">Rating 4.5+ employees</p>
              </div>
              <div className="bg-blue-50 rounded-lg p-6">
                <h4 className="font-medium text-blue-900 mb-2">Reviews Completed</h4>
                <p className="text-3xl font-bold text-blue-600">89%</p>
                <p className="text-sm text-blue-600 mt-1">This quarter</p>
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h4 className="font-medium text-gray-900 mb-4">Performance Distribution</h4>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="rating" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#8B5CF6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        );

      case 'headcount':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-blue-50 rounded-lg p-6">
                <h4 className="font-medium text-blue-900 mb-2">Total Employees</h4>
                <p className="text-3xl font-bold text-blue-600">126</p>
                <p className="text-sm text-blue-600 mt-1">Active headcount</p>
              </div>
              <div className="bg-green-50 rounded-lg p-6">
                <h4 className="font-medium text-green-900 mb-2">New Hires</h4>
                <p className="text-3xl font-bold text-green-600">8</p>
                <p className="text-sm text-green-600 mt-1">This month</p>
              </div>
              <div className="bg-purple-50 rounded-lg p-6">
                <h4 className="font-medium text-purple-900 mb-2">Growth Rate</h4>
                <p className="text-3xl font-bold text-purple-600">12%</p>
                <p className="text-sm text-purple-600 mt-1">Year over year</p>
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h4 className="font-medium text-gray-900 mb-4">Headcount by Department</h4>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={headcountData}
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="count"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {headcountData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        );

      case 'training':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-green-50 rounded-lg p-6">
                <h4 className="font-medium text-green-900 mb-2">Completion Rate</h4>
                <p className="text-3xl font-bold text-green-600">78%</p>
                <p className="text-sm text-green-600 mt-1">Average across all courses</p>
              </div>
              <div className="bg-blue-50 rounded-lg p-6">
                <h4 className="font-medium text-blue-900 mb-2">Training Hours</h4>
                <p className="text-3xl font-bold text-blue-600">2,670</p>
                <p className="text-sm text-blue-600 mt-1">Total this quarter</p>
              </div>
              <div className="bg-purple-50 rounded-lg p-6">
                <h4 className="font-medium text-purple-900 mb-2">Certifications</h4>
                <p className="text-3xl font-bold text-purple-600">45</p>
                <p className="text-sm text-purple-600 mt-1">Earned this year</p>
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h4 className="font-medium text-gray-900 mb-4">Training Progress</h4>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={trainingData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="completed" stroke="#10B981" strokeWidth={2} />
                  <Line type="monotone" dataKey="enrolled" stroke="#3B82F6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        );

      case 'turnover':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-green-50 rounded-lg p-6">
                <h4 className="font-medium text-green-900 mb-2">Retention Rate</h4>
                <p className="text-3xl font-bold text-green-600">96.4%</p>
                <p className="text-sm text-green-600 mt-1">12-month average</p>
              </div>
              <div className="bg-blue-50 rounded-lg p-6">
                <h4 className="font-medium text-blue-900 mb-2">New Hires</h4>
                <p className="text-3xl font-bold text-blue-600">61</p>
                <p className="text-sm text-blue-600 mt-1">Last 6 months</p>
              </div>
              <div className="bg-red-50 rounded-lg p-6">
                <h4 className="font-medium text-red-900 mb-2">Departures</h4>
                <p className="text-3xl font-bold text-red-600">27</p>
                <p className="text-sm text-red-600 mt-1">Last 6 months</p>
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h4 className="font-medium text-gray-900 mb-4">Hiring vs Departures</h4>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={turnoverData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="hires" fill="#10B981" />
                  <Bar dataKey="departures" fill="#EF4444" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        );

      default:
        return <div>Select a report type to view data</div>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{t('nav.reports')}</h1>
          <p className="text-gray-600 mt-1">Generate comprehensive HR analytics and reports</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button 
            onClick={generateReport}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
          >
            <BarChart3 size={20} />
            <span>Generate Report</span>
          </button>
          <div className="relative">
            <button className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition-colors flex items-center space-x-2">
              <Download size={20} />
              <span>Export</span>
            </button>
          </div>
        </div>
      </div>

      {/* Report Selection */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">Report Type</label>
            <select
              value={selectedReport}
              onChange={(e) => setSelectedReport(e.target.value)}
              className="w-full lg:w-64 border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {reportTypes.map((type) => (
                <option key={type.id} value={type.id}>
                  {type.name}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-center space-x-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="last_7_days">Last 7 days</option>
                <option value="last_30_days">Last 30 days</option>
                <option value="last_90_days">Last 90 days</option>
                <option value="last_6_months">Last 6 months</option>
                <option value="last_year">Last year</option>
                <option value="custom">Custom range</option>
              </select>
            </div>
            
            <div className="flex items-center space-x-2 pt-6">
              <button className="p-2 text-gray-400 hover:text-gray-600">
                <Filter size={20} />
              </button>
              <button className="p-2 text-gray-400 hover:text-gray-600">
                <Calendar size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Report Description */}
        <div className="mt-4 p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">
            {reportTypes.find(type => type.id === selectedReport)?.description}
          </p>
        </div>
      </div>

      {/* Report Content */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">
            {reportTypes.find(type => type.id === selectedReport)?.name}
          </h3>
          <div className="flex space-x-2">
            <button 
              onClick={() => exportReport('pdf')}
              className="text-sm bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded transition-colors"
            >
              PDF
            </button>
            <button 
              onClick={() => exportReport('excel')}
              className="text-sm bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded transition-colors"
            >
              Excel
            </button>
            <button 
              onClick={() => exportReport('csv')}
              className="text-sm bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded transition-colors"
            >
              CSV
            </button>
          </div>
        </div>

        {renderReportContent()}
      </div>

      {/* Quick Reports */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Reports</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {reportTypes.map((type) => {
            const Icon = type.icon;
            return (
              <button
                key={type.id}
                onClick={() => setSelectedReport(type.id)}
                className={`p-4 border rounded-lg text-left hover:bg-gray-50 transition-colors ${
                  selectedReport === type.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${
                    selectedReport === type.id ? 'bg-blue-100' : 'bg-gray-100'
                  }`}>
                    <Icon size={20} className={
                      selectedReport === type.id ? 'text-blue-600' : 'text-gray-600'
                    } />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">{type.name}</h4>
                    <p className="text-sm text-gray-500">{type.description}</p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Reports;