import React, { useState } from 'react';
import { DollarSign, Download, Eye, Calculator, TrendingUp, Users, Calendar, FileText } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { format, parseISO } from 'date-fns';

const Payroll: React.FC = () => {
  const { t } = useLanguage();
  const { user, hasPermission } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'payslips' | 'processing' | 'reports'>('overview');
  const [selectedPeriod, setSelectedPeriod] = useState('2024-01');

  const payrollSummary = {
    totalEmployees: 1234,
    totalPayroll: 2450000,
    averageSalary: 65000,
    totalDeductions: 245000,
    totalBenefits: 185000,
    netPayroll: 2205000
  };

  const mockPayslips = [
    {
      id: '1',
      employeeId: 'EMP001',
      employeeName: 'John Doe',
      department: 'Engineering',
      period: '2024-01',
      basicSalary: 5000,
      allowances: 1000,
      overtime: 500,
      grossPay: 6500,
      taxDeduction: 1300,
      socialSecurity: 390,
      insurance: 200,
      totalDeductions: 1890,
      netPay: 4610,
      status: 'processed',
      processedAt: '2024-01-31T10:00:00Z'
    },
    {
      id: '2',
      employeeId: 'EMP002',
      employeeName: 'Sarah Johnson',
      department: 'HR',
      period: '2024-01',
      basicSalary: 4500,
      allowances: 800,
      overtime: 200,
      grossPay: 5500,
      taxDeduction: 1100,
      socialSecurity: 330,
      insurance: 200,
      totalDeductions: 1630,
      netPay: 3870,
      status: 'processed',
      processedAt: '2024-01-31T10:00:00Z'
    },
    {
      id: '3',
      employeeId: 'EMP003',
      employeeName: 'Mike Chen',
      department: 'Marketing',
      period: '2024-01',
      basicSalary: 4000,
      allowances: 600,
      overtime: 300,
      grossPay: 4900,
      taxDeduction: 980,
      socialSecurity: 294,
      insurance: 200,
      totalDeductions: 1474,
      netPay: 3426,
      status: 'pending',
      processedAt: null
    }
  ];

  const payrollTrends = [
    { month: 'Jul', amount: 2200000 },
    { month: 'Aug', amount: 2250000 },
    { month: 'Sep', amount: 2300000 },
    { month: 'Oct', amount: 2350000 },
    { month: 'Nov', amount: 2400000 },
    { month: 'Dec', amount: 2450000 }
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const PayslipModal = ({ payslip, onClose }: { payslip: any, onClose: () => void }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Payslip Details</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            ×
          </button>
        </div>
        
        <div className="space-y-6">
          {/* Employee Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600">Employee</p>
                <p className="font-medium">{payslip.employeeName}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Employee ID</p>
                <p className="font-medium">{payslip.employeeId}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Department</p>
                <p className="font-medium">{payslip.department}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Pay Period</p>
                <p className="font-medium">{payslip.period}</p>
              </div>
            </div>
          </div>

          {/* Earnings */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Earnings</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Basic Salary</span>
                <span className="font-medium">{formatCurrency(payslip.basicSalary)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Allowances</span>
                <span className="font-medium">{formatCurrency(payslip.allowances)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Overtime</span>
                <span className="font-medium">{formatCurrency(payslip.overtime)}</span>
              </div>
              <div className="flex justify-between border-t pt-2 font-semibold">
                <span>Gross Pay</span>
                <span>{formatCurrency(payslip.grossPay)}</span>
              </div>
            </div>
          </div>

          {/* Deductions */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Deductions</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Tax</span>
                <span className="font-medium text-red-600">-{formatCurrency(payslip.taxDeduction)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Social Security</span>
                <span className="font-medium text-red-600">-{formatCurrency(payslip.socialSecurity)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Insurance</span>
                <span className="font-medium text-red-600">-{formatCurrency(payslip.insurance)}</span>
              </div>
              <div className="flex justify-between border-t pt-2 font-semibold">
                <span>Total Deductions</span>
                <span className="text-red-600">-{formatCurrency(payslip.totalDeductions)}</span>
              </div>
            </div>
          </div>

          {/* Net Pay */}
          <div className="bg-green-50 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold text-gray-900">Net Pay</span>
              <span className="text-2xl font-bold text-green-600">{formatCurrency(payslip.netPay)}</span>
            </div>
          </div>

          <div className="flex space-x-3">
            <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors">
              Download PDF
            </button>
            <button className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors">
              Send Email
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const [selectedPayslip, setSelectedPayslip] = useState(null);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{t('nav.payroll')}</h1>
          <p className="text-gray-600 mt-1">Manage payroll processing and employee compensation</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2">
            <Calculator size={20} />
            <span>Process Payroll</span>
          </button>
          <button className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition-colors">
            <Download size={20} />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { key: 'overview', label: 'Overview', icon: TrendingUp },
              { key: 'payslips', label: 'Payslips', icon: FileText },
              { key: 'processing', label: 'Processing', icon: Calculator },
              { key: 'reports', label: 'Reports', icon: Download }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.key
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-6">
                  <div className="flex items-center">
                    <div className="p-3 bg-blue-500 rounded-lg">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-blue-600">Total Employees</p>
                      <p className="text-2xl font-bold text-blue-900">{payrollSummary.totalEmployees.toLocaleString()}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-6">
                  <div className="flex items-center">
                    <div className="p-3 bg-green-500 rounded-lg">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-green-600">Total Payroll</p>
                      <p className="text-2xl font-bold text-green-900">{formatCurrency(payrollSummary.totalPayroll)}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg p-6">
                  <div className="flex items-center">
                    <div className="p-3 bg-purple-500 rounded-lg">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-purple-600">Average Salary</p>
                      <p className="text-2xl font-bold text-purple-900">{formatCurrency(payrollSummary.averageSalary)}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Payroll Breakdown */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Payroll Breakdown</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Gross Payroll</span>
                      <span className="font-semibold">{formatCurrency(payrollSummary.totalPayroll)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Total Deductions</span>
                      <span className="font-semibold text-red-600">-{formatCurrency(payrollSummary.totalDeductions)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Benefits</span>
                      <span className="font-semibold text-green-600">+{formatCurrency(payrollSummary.totalBenefits)}</span>
                    </div>
                    <div className="border-t pt-4">
                      <div className="flex justify-between items-center">
                        <span className="text-lg font-semibold text-gray-900">Net Payroll</span>
                        <span className="text-xl font-bold text-blue-600">{formatCurrency(payrollSummary.netPayroll)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Payroll Trends</h3>
                  <div className="space-y-3">
                    {payrollTrends.map((trend, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-gray-600">{trend.month} 2023</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-24 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${(trend.amount / 2500000) * 100}%` }}
                            />
                          </div>
                          <span className="font-medium text-sm">{formatCurrency(trend.amount)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'payslips' && (
            <div className="space-y-6">
              {/* Period Selector */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Calendar size={20} className="text-gray-400" />
                    <select
                      value={selectedPeriod}
                      onChange={(e) => setSelectedPeriod(e.target.value)}
                      className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="2024-01">January 2024</option>
                      <option value="2023-12">December 2023</option>
                      <option value="2023-11">November 2023</option>
                    </select>
                  </div>
                </div>
                <div className="text-sm text-gray-600">
                  {mockPayslips.length} payslip{mockPayslips.length !== 1 ? 's' : ''}
                </div>
              </div>

              {/* Payslips Table */}
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Employee
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Gross Pay
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Deductions
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Net Pay
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {mockPayslips.map((payslip) => (
                      <tr key={payslip.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-white">
                                {payslip.employeeName.split(' ').map(n => n[0]).join('')}
                              </span>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{payslip.employeeName}</div>
                              <div className="text-sm text-gray-500">{payslip.employeeId}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatCurrency(payslip.grossPay)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600">
                          -{formatCurrency(payslip.totalDeductions)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600">
                          {formatCurrency(payslip.netPay)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                            payslip.status === 'processed' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {payslip.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center space-x-2">
                            <button 
                              onClick={() => setSelectedPayslip(payslip)}
                              className="text-blue-600 hover:text-blue-900"
                            >
                              <Eye size={16} />
                            </button>
                            <button className="text-gray-600 hover:text-gray-900">
                              <Download size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'processing' && (
            <div className="space-y-6">
              <div className="text-center py-12">
                <Calculator className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">Payroll Processing</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Configure and run payroll processing for the selected period.
                </p>
                <div className="mt-6">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors">
                    Start Payroll Processing
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'reports' && (
            <div className="space-y-6">
              <div className="text-center py-12">
                <FileText className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">Payroll Reports</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Generate comprehensive payroll reports and analytics.
                </p>
                <div className="mt-6 space-x-4">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                    Monthly Report
                  </button>
                  <button className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition-colors">
                    Tax Report
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {selectedPayslip && (
        <PayslipModal 
          payslip={selectedPayslip} 
          onClose={() => setSelectedPayslip(null)} 
        />
      )}
    </div>
  );
};

export default Payroll;