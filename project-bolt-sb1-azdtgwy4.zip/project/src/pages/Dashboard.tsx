import React from 'react';
import { Users, Clock, Calendar, TrendingUp, Award, Briefcase } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { t } = useLanguage();

  const stats = [
    {
      name: t('dashboard.totalEmployees'),
      value: '1,234',
      change: '+12%',
      changeType: 'positive',
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      name: t('dashboard.activeEmployees'),
      value: '1,180',
      change: '+3%',
      changeType: 'positive',
      icon: Clock,
      color: 'bg-green-500'
    },
    {
      name: t('dashboard.pendingLeaves'),
      value: '23',
      change: '-8%',
      changeType: 'negative',
      icon: Calendar,
      color: 'bg-yellow-500'
    },
    {
      name: t('dashboard.todayAttendance'),
      value: '95.2%',
      change: '+1.2%',
      changeType: 'positive',
      icon: TrendingUp,
      color: 'bg-purple-500'
    }
  ];

  const attendanceData = [
    { day: 'Mon', present: 1150, absent: 80 },
    { day: 'Tue', present: 1180, absent: 50 },
    { day: 'Wed', present: 1200, absent: 30 },
    { day: 'Thu', present: 1170, absent: 60 },
    { day: 'Fri', present: 1140, absent: 90 },
    { day: 'Sat', present: 800, absent: 430 },
    { day: 'Sun', present: 600, absent: 630 }
  ];

  const departmentData = [
    { name: 'Engineering', value: 450, color: '#3B82F6' },
    { name: 'Sales', value: 280, color: '#10B981' },
    { name: 'Marketing', value: 180, color: '#F59E0B' },
    { name: 'HR', value: 120, color: '#EF4444' },
    { name: 'Finance', value: 100, color: '#8B5CF6' },
    { name: 'Operations', value: 104, color: '#06B6D4' }
  ];

  const performanceData = [
    { month: 'Jan', score: 85 },
    { month: 'Feb', score: 87 },
    { month: 'Mar', score: 86 },
    { month: 'Apr', score: 88 },
    { month: 'May', score: 90 },
    { month: 'Jun', score: 92 }
  ];

  const upcomingBirthdays = [
    { name: 'Sarah Johnson', department: 'HR', date: 'Today', avatar: 'SJ' },
    { name: 'Mike Chen', department: 'Engineering', date: 'Tomorrow', avatar: 'MC' },
    { name: 'Emily Davis', department: 'Marketing', date: 'Jan 18', avatar: 'ED' },
    { name: 'John Smith', department: 'Sales', date: 'Jan 20', avatar: 'JS' }
  ];

  const recentActivities = [
    { type: 'leave', message: 'John Doe applied for annual leave', time: '2 hours ago', icon: Calendar },
    { type: 'hire', message: 'New employee Sarah Wilson joined Engineering', time: '4 hours ago', icon: Users },
    { type: 'performance', message: 'Q4 performance reviews completed', time: '1 day ago', icon: Award },
    { type: 'recruitment', message: 'Software Developer position posted', time: '2 days ago', icon: Briefcase }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            {t('dashboard.welcome')}, {user?.firstName}!
          </h1>
          <p className="text-gray-600 mt-1">
            Here's what's happening with your team today.
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
            Generate Report
          </button>
          <button className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition-colors">
            {t('common.export')}
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <span className={`text-sm font-medium ${
                      stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {stat.change}
                    </span>
                    <span className="text-sm text-gray-500 ml-1">vs last month</span>
                  </div>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Attendance Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Weekly Attendance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={attendanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="present" stackId="a" fill="#3B82F6" />
              <Bar dataKey="absent" stackId="a" fill="#EF4444" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Department Distribution */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Department Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={departmentData}
                cx="50%"
                cy="50%"
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {departmentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Performance Trend */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Trend</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="score" stroke="#3B82F6" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Upcoming Birthdays */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">{t('dashboard.upcomingBirthdays')}</h3>
          <div className="space-y-4">
            {upcomingBirthdays.map((person, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-sm font-medium text-white">{person.avatar}</span>
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{person.name}</p>
                  <p className="text-sm text-gray-500">{person.department}</p>
                </div>
                <span className="text-sm text-blue-600 font-medium">{person.date}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activities */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activities</h3>
          <div className="space-y-4">
            {recentActivities.map((activity, index) => {
              const Icon = activity.icon;
              return (
                <div key={index} className="flex items-start space-x-3">
                  <div className="p-2 bg-gray-100 rounded-lg">
                    <Icon className="w-4 h-4 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">{activity.message}</p>
                    <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;