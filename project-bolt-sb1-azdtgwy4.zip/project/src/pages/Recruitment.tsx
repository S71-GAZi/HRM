import React, { useState } from 'react';
import { Briefcase, Users, Calendar, Eye, Plus, Filter, MapPin, Clock, CheckCircle, XCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { format, parseISO } from 'date-fns';

const Recruitment: React.FC = () => {
  const { t } = useLanguage();
  const { user, hasPermission } = useAuth();
  const [activeTab, setActiveTab] = useState<'jobs' | 'applications' | 'interviews' | 'pipeline'>('jobs');
  const [showJobModal, setShowJobModal] = useState(false);

  const recruitmentStats = {
    openJobs: 12,
    totalApplications: 156,
    scheduledInterviews: 8,
    pendingOffers: 3,
    hiredThisMonth: 5,
    averageTimeToHire: 18
  };

  const mockJobs = [
    {
      id: '1',
      title: 'Senior Software Engineer',
      department: 'Engineering',
      location: 'New York, NY',
      type: 'full_time',
      status: 'open',
      applications: 24,
      description: 'We are looking for a senior software engineer to join our growing team...',
      requirements: ['5+ years React experience', 'TypeScript proficiency', 'Team leadership'],
      salary: { min: 120000, max: 150000, currency: 'USD' },
      createdAt: '2024-01-10T00:00:00Z',
      deadline: '2024-02-28T00:00:00Z'
    },
    {
      id: '2',
      title: 'Product Manager',
      department: 'Product',
      location: 'San Francisco, CA',
      type: 'full_time',
      status: 'open',
      applications: 18,
      description: 'Join our product team to drive innovation and user experience...',
      requirements: ['3+ years product management', 'Agile methodology', 'Data-driven mindset'],
      salary: { min: 110000, max: 140000, currency: 'USD' },
      createdAt: '2024-01-15T00:00:00Z',
      deadline: '2024-03-15T00:00:00Z'
    },
    {
      id: '3',
      title: 'UX Designer',
      department: 'Design',
      location: 'Remote',
      type: 'full_time',
      status: 'closed',
      applications: 32,
      description: 'Create beautiful and intuitive user experiences for our products...',
      requirements: ['Portfolio of UX work', 'Figma proficiency', 'User research experience'],
      salary: { min: 85000, max: 110000, currency: 'USD' },
      createdAt: '2024-01-05T00:00:00Z',
      deadline: '2024-02-15T00:00:00Z'
    }
  ];

  const mockApplications = [
    {
      id: '1',
      jobId: '1',
      jobTitle: 'Senior Software Engineer',
      candidateName: 'Alex Johnson',
      candidateEmail: 'alex.johnson@email.com',
      status: 'interview',
      appliedAt: '2024-01-20T00:00:00Z',
      experience: '6 years',
      location: 'New York, NY',
      resumeUrl: '#',
      coverLetter: 'I am excited to apply for the Senior Software Engineer position...',
      currentStage: 'Technical Interview',
      rating: 4.2
    },
    {
      id: '2',
      jobId: '1',
      jobTitle: 'Senior Software Engineer',
      candidateName: 'Sarah Chen',
      candidateEmail: 'sarah.chen@email.com',
      status: 'screening',
      appliedAt: '2024-01-18T00:00:00Z',
      experience: '5 years',
      location: 'Brooklyn, NY',
      resumeUrl: '#',
      coverLetter: 'With my extensive background in React and TypeScript...',
      currentStage: 'Initial Screening',
      rating: 3.8
    },
    {
      id: '3',
      jobId: '2',
      jobTitle: 'Product Manager',
      candidateName: 'Michael Rodriguez',
      candidateEmail: 'michael.r@email.com',
      status: 'offer',
      appliedAt: '2024-01-12T00:00:00Z',
      experience: '4 years',
      location: 'San Francisco, CA',
      resumeUrl: '#',
      coverLetter: 'I have been following your company\'s growth and innovation...',
      currentStage: 'Offer Extended',
      rating: 4.7
    }
  ];

  const mockInterviews = [
    {
      id: '1',
      applicationId: '1',
      candidateName: 'Alex Johnson',
      jobTitle: 'Senior Software Engineer',
      date: '2024-01-25',
      time: '14:00',
      interviewer: 'Emily Chen',
      type: 'video',
      status: 'scheduled',
      notes: '',
      rating: null
    },
    {
      id: '2',
      applicationId: '3',
      candidateName: 'Michael Rodriguez',
      jobTitle: 'Product Manager',
      date: '2024-01-22',
      time: '10:00',
      interviewer: 'David Kim',
      type: 'in_person',
      status: 'completed',
      notes: 'Strong product sense and leadership experience. Good cultural fit.',
      rating: 4.5
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-green-100 text-green-800';
      case 'closed': return 'bg-red-100 text-red-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'new': return 'bg-blue-100 text-blue-800';
      case 'screening': return 'bg-yellow-100 text-yellow-800';
      case 'interview': return 'bg-purple-100 text-purple-800';
      case 'offer': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'hired': return 'bg-green-100 text-green-800';
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatSalary = (salary: any) => {
    return `$${salary.min.toLocaleString()} - $${salary.max.toLocaleString()}`;
  };

  const JobModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Job Posting</h3>
        <form className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Job Title</label>
              <input 
                type="text" 
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="e.g. Senior Software Engineer"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
              <select className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500">
                <option>Engineering</option>
                <option>Product</option>
                <option>Design</option>
                <option>Marketing</option>
                <option>Sales</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
              <input 
                type="text" 
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="e.g. New York, NY or Remote"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Employment Type</label>
              <select className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500">
                <option value="full_time">Full Time</option>
                <option value="part_time">Part Time</option>
                <option value="contract">Contract</option>
                <option value="internship">Internship</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Job Description</label>
            <textarea 
              rows={4} 
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
              placeholder="Describe the role, responsibilities, and what makes this opportunity exciting..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Requirements</label>
            <textarea 
              rows={3} 
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
              placeholder="List the key requirements and qualifications..."
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Minimum Salary</label>
              <input 
                type="number" 
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="80000"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Maximum Salary</label>
              <input 
                type="number" 
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
                placeholder="120000"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Application Deadline</label>
            <input 
              type="date" 
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex space-x-3 pt-4">
            <button 
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Create Job Posting
            </button>
            <button 
              type="button"
              onClick={() => setShowJobModal(false)}
              className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{t('recruitment.title')}</h1>
          <p className="text-gray-600 mt-1">Manage job postings, applications, and hiring pipeline</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button 
            onClick={() => setShowJobModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>New Job</span>
          </button>
          <button className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg transition-colors">
            Export Data
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Briefcase className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Open Jobs</p>
              <p className="text-2xl font-bold text-gray-900">{recruitmentStats.openJobs}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-lg">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Applications</p>
              <p className="text-2xl font-bold text-gray-900">{recruitmentStats.totalApplications}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-purple-100 rounded-lg">
              <Calendar className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Interviews</p>
              <p className="text-2xl font-bold text-gray-900">{recruitmentStats.scheduledInterviews}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-yellow-100 rounded-lg">
              <CheckCircle className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Offers</p>
              <p className="text-2xl font-bold text-gray-900">{recruitmentStats.pendingOffers}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-lg">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Hired</p>
              <p className="text-2xl font-bold text-gray-900">{recruitmentStats.hiredThisMonth}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Clock className="w-6 h-6 text-indigo-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Avg. Time</p>
              <p className="text-2xl font-bold text-gray-900">{recruitmentStats.averageTimeToHire}d</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { key: 'jobs', label: 'Job Openings', icon: Briefcase },
              { key: 'applications', label: 'Applications', icon: Users },
              { key: 'interviews', label: 'Interviews', icon: Calendar },
              { key: 'pipeline', label: 'Pipeline', icon: CheckCircle }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.key
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'jobs' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Job Openings</h3>
                <div className="text-sm text-gray-600">
                  {mockJobs.length} job{mockJobs.length !== 1 ? 's' : ''}
                </div>
              </div>

              <div className="space-y-4">
                {mockJobs.map((job) => (
                  <div key={job.id} className="border border-gray-200 rounded-lg p-6 hover:bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h4 className="text-lg font-medium text-gray-900">{job.title}</h4>
                          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(job.status)}`}>
                            {job.status}
                          </span>
                        </div>
                        <div className="flex items-center space-x-6 text-sm text-gray-500 mb-3">
                          <span className="flex items-center space-x-1">
                            <Briefcase size={14} />
                            <span>{job.department}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <MapPin size={14} />
                            <span>{job.location}</span>
                          </span>
                          <span className="capitalize">{job.type.replace('_', ' ')}</span>
                          <span>{formatSalary(job.salary)}</span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{job.description}</p>
                        <div className="flex items-center space-x-6 text-sm text-gray-500">
                          <span>{job.applications} applications</span>
                          <span>Posted {format(parseISO(job.createdAt), 'MMM d, yyyy')}</span>
                          <span>Deadline {format(parseISO(job.deadline), 'MMM d, yyyy')}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button className="text-blue-600 hover:text-blue-900">
                          <Eye size={16} />
                        </button>
                        <button className="text-gray-600 hover:text-gray-900">
                          Edit
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'applications' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Applications</h3>
                <div className="flex items-center space-x-4">
                  <select className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500">
                    <option>All Jobs</option>
                    <option>Senior Software Engineer</option>
                    <option>Product Manager</option>
                    <option>UX Designer</option>
                  </select>
                  <select className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500">
                    <option>All Status</option>
                    <option>New</option>
                    <option>Screening</option>
                    <option>Interview</option>
                    <option>Offer</option>
                  </select>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Candidate
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Job
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Applied
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Rating
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {mockApplications.map((application) => (
                      <tr key={application.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">{application.candidateName}</div>
                            <div className="text-sm text-gray-500">{application.candidateEmail}</div>
                            <div className="text-sm text-gray-500">{application.experience} experience</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{application.jobTitle}</div>
                          <div className="text-sm text-gray-500">{application.currentStage}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(application.status)}`}>
                            {application.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {format(parseISO(application.appliedAt), 'MMM d, yyyy')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <span className="text-sm font-medium text-gray-900">{application.rating}/5</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center space-x-2">
                            <button className="text-blue-600 hover:text-blue-900">
                              <Eye size={16} />
                            </button>
                            <button className="text-green-600 hover:text-green-900">
                              <CheckCircle size={16} />
                            </button>
                            <button className="text-red-600 hover:text-red-900">
                              <XCircle size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'interviews' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Scheduled Interviews</h3>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                  Schedule Interview
                </button>
              </div>

              <div className="space-y-4">
                {mockInterviews.map((interview) => (
                  <div key={interview.id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h4 className="font-medium text-gray-900">{interview.candidateName}</h4>
                          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(interview.status)}`}>
                            {interview.status}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{interview.jobTitle}</p>
                        <div className="flex items-center space-x-6 text-sm text-gray-500 mb-3">
                          <span className="flex items-center space-x-1">
                            <Calendar size={14} />
                            <span>{format(parseISO(interview.date), 'MMM d, yyyy')} at {interview.time}</span>
                          </span>
                          <span>Interviewer: {interview.interviewer}</span>
                          <span className="capitalize">{interview.type.replace('_', ' ')}</span>
                        </div>
                        {interview.status === 'completed' && interview.notes && (
                          <div className="mt-3">
                            <p className="text-sm text-gray-600">{interview.notes}</p>
                            {interview.rating && (
                              <div className="mt-2 flex items-center space-x-2">
                                <span className="text-sm text-gray-500">Rating:</span>
                                <span className="text-sm font-medium">{interview.rating}/5</span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <button className="text-blue-600 hover:text-blue-900">
                          <Eye size={16} />
                        </button>
                        {interview.status === 'scheduled' && (
                          <button className="text-gray-600 hover:text-gray-900">
                            Edit
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'pipeline' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-gray-900">Hiring Pipeline</h3>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                {[
                  { stage: 'New', count: 45, color: 'bg-blue-100 text-blue-800' },
                  { stage: 'Screening', count: 28, color: 'bg-yellow-100 text-yellow-800' },
                  { stage: 'Interview', count: 12, color: 'bg-purple-100 text-purple-800' },
                  { stage: 'Offer', count: 3, color: 'bg-green-100 text-green-800' },
                  { stage: 'Hired', count: 5, color: 'bg-green-100 text-green-800' }
                ].map((stage) => (
                  <div key={stage.stage} className="bg-white border border-gray-200 rounded-lg p-6">
                    <div className="text-center">
                      <h4 className="font-medium text-gray-900 mb-2">{stage.stage}</h4>
                      <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full ${stage.color} mb-2`}>
                        <span className="text-lg font-bold">{stage.count}</span>
                      </div>
                      <p className="text-sm text-gray-500">candidates</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {showJobModal && <JobModal />}
    </div>
  );
};

export default Recruitment;