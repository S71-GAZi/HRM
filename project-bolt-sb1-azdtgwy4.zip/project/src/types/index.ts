export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'hr_manager' | 'employee' | 'department_head';
  department: string;
  position: string;
  avatar?: string;
  timezone: string;
  language: string;
  isActive: boolean;
  createdAt: string;
  lastLogin?: string;
}

export interface Employee extends User {
  employeeId: string;
  phoneNumber: string;
  address: string;
  dateOfBirth: string;
  hireDate: string;
  salary?: number;
  manager?: string;
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  documents: Document[];
  skills: Skill[];
  performance: Performance[];
}

export interface Document {
  id: string;
  name: string;
  type: 'contract' | 'id' | 'certificate' | 'other';
  url: string;
  uploadedAt: string;
  expiryDate?: string;
}

export interface Skill {
  id: string;
  name: string;
  level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  certifications: string[];
}

export interface Performance {
  id: string;
  period: string;
  rating: number;
  goals: Goal[];
  feedback: string;
  reviewDate: string;
  reviewerId: string;
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  status: 'not_started' | 'in_progress' | 'completed';
  dueDate: string;
  weight: number;
}

export interface Attendance {
  id: string;
  employeeId: string;
  date: string;
  clockIn: string;
  clockOut?: string;
  breakDuration: number;
  totalHours: number;
  status: 'present' | 'absent' | 'late' | 'half_day';
  location: string;
  notes?: string;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  type: 'annual' | 'sick' | 'maternity' | 'paternity' | 'emergency' | 'unpaid';
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  approverId?: string;
  appliedAt: string;
  processedAt?: string;
  comments?: string;
}

export interface Job {
  id: string;
  title: string;
  department: string;
  location: string;
  type: 'full_time' | 'part_time' | 'contract' | 'internship';
  description: string;
  requirements: string[];
  salary: {
    min: number;
    max: number;
    currency: string;
  };
  status: 'open' | 'closed' | 'draft';
  applications: Application[];
  createdAt: string;
  deadline: string;
}

export interface Application {
  id: string;
  jobId: string;
  candidateName: string;
  candidateEmail: string;
  resumeUrl: string;
  coverLetter: string;
  status: 'new' | 'screening' | 'interview' | 'offer' | 'rejected' | 'hired';
  appliedAt: string;
  interviews: Interview[];
}

export interface Interview {
  id: string;
  date: string;
  time: string;
  interviewer: string;
  type: 'phone' | 'video' | 'in_person';
  status: 'scheduled' | 'completed' | 'cancelled';
  feedback?: string;
  rating?: number;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: string;
  actionUrl?: string;
}

export interface DashboardStats {
  totalEmployees: number;
  activeEmployees: number;
  pendingLeaves: number;
  todayAttendance: number;
  openJobs: number;
  pendingApplications: number;
  upcomingBirthdays: Employee[];
  recentHires: Employee[];
}